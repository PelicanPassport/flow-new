
# Flow – Build 23
- Advice fatigue fix: frequency control (High/Balanced/Low) with cooldowns to avoid repetition.
- Advice now includes 'Why?' expanders, confidence labels, and phrasing rotation.
- Positive insight pairing: warnings are balanced with strength-based reinforcement.
- Tomorrow preview remains, nighttime advice only when needed.
