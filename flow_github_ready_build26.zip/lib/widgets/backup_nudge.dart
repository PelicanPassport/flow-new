
import 'package:flutter/material.dart';
import '../services/backup_service.dart';

class BackupNudge extends StatelessWidget{
  final VoidCallback onBackup;
  const BackupNudge({super.key, required this.onBackup});
  @override Widget build(BuildContext context){
    return Card(color: Theme.of(context).colorScheme.tertiaryContainer, child:
      Padding(padding: const EdgeInsets.all(12),
        child: Row(children:[
          const Icon(Icons.cloud_upload_outlined),
          const SizedBox(width:8),
          const Expanded(child: Text('It’s been a while since your last backup.')),
          TextButton(onPressed: onBackup, child: const Text('Backup now'))
        ]),
      )
    );
  }
}
