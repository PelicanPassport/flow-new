
import 'package:flutter/material.dart';

class ThemedBackground extends StatelessWidget{
  final Widget child;
  const ThemedBackground({super.key, required this.child});
  @override Widget build(BuildContext context){
    final cs = Theme.of(context).colorScheme;
    final top = cs.surfaceVariant.withOpacity(0.35);
    final bottom = cs.surface;
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter, end: Alignment.bottomCenter,
          colors: [top, bottom],
        )
      ),
      child: child,
    );
  }
}
