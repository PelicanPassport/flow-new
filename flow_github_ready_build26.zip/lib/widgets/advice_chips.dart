
import 'package:flutter/material.dart';

class AdviceChip extends StatelessWidget{
  final IconData icon;
  final String text;
  final Color? color;
  const AdviceChip({super.key, required this.icon, required this.text, this.color});
  @override Widget build(BuildContext context){
    final c = color ?? Theme.of(context).colorScheme.secondary;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: c.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: c.withOpacity(0.35)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children:[
        Icon(icon, size: 18, color: c),
        const SizedBox(width: 8),
        Text(text, style: TextStyle(color: Theme.of(context).colorScheme.onSurface)),
      ]),
    );
  }
}
