
import 'package:flutter/material.dart';

class EntryCard extends StatelessWidget{
  final TextEditingController controller;
  final VoidCallback onSave;
  final String prompt;
  const EntryCard({super.key, required this.controller, required this.onSave, required this.prompt});

  @override Widget build(BuildContext context){
    final cs = Theme.of(context).colorScheme;
    return Card(
      elevation: 4,
      shadowColor: cs.primary.withOpacity(0.2),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children:[
                Icon(Icons.edit_rounded, color: cs.primary),
                const SizedBox(width: 8),
                Text(prompt, style: Theme.of(context).textTheme.titleMedium),
              ],
            ),
            const SizedBox(height: 12),
            AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              curve: Curves.easeOutCubic,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: cs.primary.withOpacity(0.25)),
              ),
              child: TextField(
                controller: controller,
                autofocus: true,
                maxLines: null,
                decoration: const InputDecoration.collapsed(hintText: 'Write freely…'),
              ),
            ),
            const SizedBox(height: 16),
            Align(
              alignment: Alignment.centerRight,
              child: FilledButton.icon(
                onPressed: onSave,
                icon: const Icon(Icons.check_rounded),
                label: const Text('Save'),
              ),
            )
          ],
        ),
      ),
    );
  }
}
