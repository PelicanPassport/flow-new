
class JournalEntry {
  final String id;
  final DateTime dateTime; // local time
  final String text;
  final int mood;   // 0-10
  final int energy; // 0-10
  final int focus;  // 0-10
  final int 
  final bool workDay;
  final bool nightShift;
  final bool ranToday;
  final int writeDurationSec;
  final int deletions;
  final int words;
  final int sentences;
  final double typeTokenRatio;
  final String tagsCsv;

  JournalEntry({
    required this.id,
    required this.dateTime,
    required this.text,
    required this.mood,
    required this.energy,
    required this.focus,
    required this.
    required this.workDay,
    required this.nightShift,
    required this.ranToday,
    required this.writeDurationSec,
    required this.deletions,
    required this.words,
    required this.sentences,
    required this.typeTokenRatio,
    required this.tagsCsv,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'dateTime': dateTime.toIso8601String(),
    'text': text,
    'mood': mood,
    'energy': energy,
    'focus': focus,
    '
    'workDay': workDay ? 1 : 0,
    'nightShift': nightShift ? 1 : 0,
    'ranToday': ranToday ? 1 : 0,
    'writeDurationSec': writeDurationSec,
    'deletions': deletions,
    'words': words,
    'sentences': sentences,
    'typeTokenRatio': typeTokenRatio,
    'tagsCsv': tagsCsv,
  };

  factory JournalEntry.fromMap(Map<String, dynamic> m) => JournalEntry(
    id: m['id'] as String,
    dateTime: DateTime.parse(m['dateTime'] as String),
    text: m['text'] as String,
    mood: (m['mood'] ?? 0) as int,
    energy: (m['energy'] ?? 0) as int,
    focus: (m['focus'] ?? 0) as int,
    ) as int,
    workDay: (m['workDay'] ?? 0) == 1,
    nightShift: (m['nightShift'] ?? 0) == 1,
    ranToday: (m['ranToday'] ?? 0) == 1,
    writeDurationSec: (m['writeDurationSec'] ?? 0) as int,
    deletions: (m['deletions'] ?? 0) as int,
    words: (m['words'] ?? 0) as int,
    sentences: (m['sentences'] ?? 0) as int,
    typeTokenRatio: (m['typeTokenRatio'] ?? 0.0) is int ? (m['typeTokenRatio'] as int).toDouble() : (m['typeTokenRatio'] ?? 0.0) as double,
    tagsCsv: (m['tagsCsv'] ?? '') as String,
  );
}
