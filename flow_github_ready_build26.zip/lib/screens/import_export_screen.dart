
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../services/db.dart';
import '../services/export.dart';
import '../services/import.dart';
import '../models/journal_entry.dart';

class ImportExportScreen extends StatefulWidget {
  const ImportExportScreen({super.key});
  @override
  State<ImportExportScreen> createState() => _ImportExportScreenState();
}

class _ImportExportScreenState extends State<ImportExportScreen> {
  List<JournalEntry> entries = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final all = await AppDatabase.instance.all();
    setState(() => entries = all);
  }

  Future<void> _exportCsv() async {
    final csv = toCsv(entries);
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/journal_supreme.csv');
    await file.writeAsString(csv);
    await Share.shareXFiles([XFile(file.path)], text: 'Supreme dataset CSV');
  }

  Future<void> _exportJsonL() async {
    final jsonl = toJsonL(entries);
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/journal.jsonl');
    await file.writeAsString(jsonl);
    await Share.shareXFiles([XFile(file.path)], text: 'Journal JSONL');
  }

  Future<void> _importJsonL() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['jsonl', 'json']);
    if (res == null || res.files.isEmpty) return;
    final file = File(res.files.single.path!);
    final text = await file.readAsString();
    final list = fromJsonL(text);
    for (final e in list) { await AppDatabase.instance.upsert(e); }
    await _load();
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Import complete')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Import / Export')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ElevatedButton.icon(onPressed: _exportCsv, icon: const Icon(Icons.cloud_upload), label: const Text('Export SUPREME CSV (share to Drive)')),
            const SizedBox(height: 8),
            ElevatedButton.icon(onPressed: _exportJsonL, icon: const Icon(Icons.cloud_upload), label: const Text('Export JSONL (backup/share)')),
            const SizedBox(height: 8),
            ElevatedButton.icon(onPressed: _importJsonL, icon: const Icon(Icons.download), label: const Text('Import JSONL')),
            const SizedBox(height: 16),
            Text('Entries: ${entries.length}'),
          ],
        ),
      ),
    );
  }
}
