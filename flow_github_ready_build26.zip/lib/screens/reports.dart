import '../widgets/advice_chips.dart';
import 'package:flutter/material.dart';
import 'package:collection/collection.dart';
import '../models/models.dart';
import '../services/db.dart';
import '../services/good_news.dart';
import '../services/risk_monitor.dart'; import '../services/word_analytics.dart'; import '../services/habit_analytics.dart'; import '../services/recommendations.dart'; class ReportsScreen extends StatelessWidget{ const ReportsScreen({super.key}); @override Widget build(c){return Scaffold(appBar: AppBar(title: const Text('Weekly Report')), body: ListView(padding: const EdgeInsets.all(16), children:[
        _WinsThisWeek(),Card(child: ListTile(title: const Text('KPIs'), subtitle: const Text('…'))), const SizedBox(height:12), Card(child: ListTile(title: const Text('Word themes this week'), subtitle: const Text('Top tones: gratitude, progress'))), const SizedBox(height:12), Card(child: ListTile(title: const Text('Habit impact'), subtitle: const Text('Run — Δ mood 0.60, Δ stress 0.30'))), const SizedBox(height:12), Card(child: ListTile(title: const Text('Suggestions for next week'), subtitle: const Text('Wind‑down plan; two outdoor walks'))),]));}}
class _YTDHighlights extends StatefulWidget{ @override State<_YTDHighlights> createState()=> _YTDHighlightsState(); }
class _YTDHighlightsState extends State<_YTDHighlights>{
  List<JournalEntry> all = [];
  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async { all = await AppDatabase.instance.all(); if (mounted) setState((){}); }
  @override Widget build(BuildContext c){
    if (all.isEmpty) return SizedBox.shrink();
    final now = DateTime.now();
    final yStart = DateTime(now.year, 1, 1);
    final wStart = DateTime(now.year, now.month, now.day).subtract(Duration(days: now.weekday-1));
    final thisWeek = all.where((e)=> !e.dateTime.isBefore(wStart)).toList();
    final ytd = all.where((e)=> !e.dateTime.isBefore(yStart)).toList();

    double avgMood(List<JournalEntry> xs)=> xs.isEmpty? 0 : xs.map((e)=> e.mood).whereNotNull().average;
    double avgStress(List<JournalEntry> xs)=> xs.isEmpty? 0 : xs.map((e)=> e.stress).whereNotNull().average;
    int totalWords(List<JournalEntry> xs)=> xs.isEmpty? 0 : xs.map((e)=> e.words??0).sum;
    int runs(List<JournalEntry> xs)=> xs.where((e)=> e.ranToday==true).length;
    int nights(List<JournalEntry> xs)=> xs.where((e)=> e.nightShift==true).length;

    final mNow = avgMood(thisWeek), mY = avgMood(ytd);
    final sNow = avgStress(thisWeek), sY = avgStress(ytd);
    final wNow = totalWords(thisWeek), wY = (ytd.isEmpty?0: (totalWords(ytd)/((ytd.length/7).ceil())).toInt()); // rough per-week baseline
    final rNow = runs(thisWeek), rY = (runs(ytd)/((ytd.length/7).clamp(1, 52))).round();
    final nNow = nights(thisWeek), nY = (nights(ytd)/((ytd.length/7).clamp(1, 52))).round();

    double pct(double a, double b){ if (b==0) return 0; return ((a-b)/b)*100.0; }
    final changes = <Map<String, dynamic>>[
      {'label':'Mood', 'this': mNow, 'ytd': mY, 'delta': pct(mNow, mY)},
      {'label':'Stress (lower better)', 'this': sNow, 'ytd': sY, 'delta': pct(sY, sNow)}, // inverted
      {'label':'Words', 'this': wNow.toDouble(), 'ytd': wY.toDouble(), 'delta': pct(wNow.toDouble(), wY.toDouble())},
      {'label':'Runs', 'this': rNow.toDouble(), 'ytd': rY.toDouble(), 'delta': pct(rNow.toDouble(), rY.toDouble())},
      {'label':'Night shifts', 'this': nNow.toDouble(), 'ytd': nY.toDouble(), 'delta': pct(nNow.toDouble(), nY.toDouble())},
    ]..sort((a,b)=> (b['delta'] as double).abs().compareTo((a['delta'] as double).abs()));

    String arrow(double d)=> d>2? '↑' : d<-2? '↓' : '→';

    return Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
      const Text('YTD highlights (this week vs year‑to‑date)', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height:8),
      for (final c in changes.take(4)) Text('• ${c['label']}: ${arrow(c['delta'])} ${c['delta'].toStringAsFixed(1)}%  (week ${c['this'].toStringAsFixed(1)} vs YTD ${c['ytd'].toStringAsFixed(1)})'),
    ])));
  }
}

class _WinsThisWeek extends StatefulWidget{ @override State<_WinsThisWeek> createState()=> _WinsThisWeekState(); }
class _WinsThisWeekState extends State<_WinsThisWeek>{
  int rareCount = 0;
  ({double score, List<String> reasons, Map<String,int> streaks, double sentimentDelta})? res;
  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async { res = await GoodNews.evaluate(DateTime.now());
    // Count rare days in this week
    final now = DateTime.now();
    for (int i=0;i<7;i++){
      final d = now.subtract(Duration(days:i));
      final r = await RiskMonitor.evaluate(d);
      if (r.rareBadDay) rareCount++;
    }
    if (mounted) setState((){}); }
  @override Widget build(BuildContext c){
    if (res==null || res!.score < 0.6) return SizedBox.shrink();
    return Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
      const Text('Wins this week', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height:6),
      for (final r in res!.reasons.take(4)) Text('• ' + r),
      const SizedBox(height:6),
      if (res!.streaks.isNotEmpty) Text('Streaks: ' + [
        if ((res!.streaks['mood']??0)>1) 'mood ' + (res!.streaks['mood']!).toString() + 'd',
        if ((res!.streaks['low_stress']??0)>1) 'low stress ' + (res!.streaks['low_stress']!).toString() + 'd',
        if ((res!.streaks['activity']??0)>1) 'activity ' + (res!.streaks['activity']!).toString() + 'd',
      ].where((s)=> s.isNotEmpty).join('  •  ')),
    ])));
  }
}
