
import 'package:flutter/material.dart';
import '../services/advice_engine.dart';
import '../services/good_news.dart';
import '../services/risk_monitor.dart';

class EveningPlanScreen extends StatefulWidget{
  final DateTime date;
  const EveningPlanScreen({super.key, required this.date});
  @override State<EveningPlanScreen> createState()=> _EveningPlanScreenState();
}

class _EveningPlanScreenState extends State<EveningPlanScreen>{
  AdviceEngineResult? result;
  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async { final r = await AdviceEngine.generate(widget.date); if (mounted) setState(()=> result = r); }

  @override Widget build(BuildContext c){
    final r = result;
    return Scaffold(appBar: AppBar(title: const Text('Tonight & Next days')), body: r==null
      ? const Center(child: CircularProgressIndicator())
      : ListView(padding: const EdgeInsets.all(16), children:[

          FutureBuilder<RiskSnapshot>(
            future: RiskMonitor.evaluate(widget.date),
            builder: (context, snap){
              if (!snap.hasData) return const SizedBox.shrink();
              final rs = snap.data!;
              if (!rs.rareBadDay) return const SizedBox.shrink();
              return Card(color: Theme.of(context).colorScheme.errorContainer, child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
                  Text('Rare day', style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.onErrorContainer)),
                  const SizedBox(height:6),
                  for (final r in rs.reasons.take(3)) Text('• ' + r, style: TextStyle(color: Theme.of(context).colorScheme.onErrorContainer)),
                  const SizedBox(height:6),
                  Text('Plan focuses on steady recovery. This usually normalises within 24–48h for you.', style: TextStyle(color: Theme.of(context).colorScheme.onErrorContainer)),
                ]),
              ));
            }
          ),
          const SizedBox(height:12),
    

          FutureBuilder<({double score, List<String> reasons, Map<String,int> streaks, double sentimentDelta})>(
            future: GoodNews.evaluate(widget.date),
            builder: (context, snap){
              if (!snap.hasData) return const SizedBox.shrink();
              final data = snap.data!;
              if (data.score < 0.6) return const SizedBox.shrink();
              return Card(color: Theme.of(context).colorScheme.surfaceVariant, child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
                  const Text('Good news', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  for (final r in data.reasons.take(3)) Text('• ' + r),
                  const SizedBox(height:8),
                  if (data.streaks.isNotEmpty) Text('Streaks: ' + [
                    if ((data.streaks['mood']??0)>1) 'mood ' + (data.streaks['mood']!).toString() + 'd',
                    if ((data.streaks['low_stress']??0)>1) 'low stress ' + (data.streaks['low_stress']!).toString() + 'd',
                    if ((data.streaks['activity']??0)>1) 'activity ' + (data.streaks['activity']!).toString() + 'd',
                  ].where((s)=> s.isNotEmpty).join('  •  ')),
                ]),
              ));
            }
          ),
          const SizedBox(height:12),
        
          Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
            const if(showTonight) Text('Tonight', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height:8),
            Text(r.tonight),
          ]))),
          const SizedBox(height:12),
          Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
            const Text('Next 1–3 days', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height:8),
            Text(r.nextDays),
          ]))),
        ]);
  }
}


/* Advice UI helpers */
import 'package:flutter/material.dart';

Widget adviceTile(BuildContext context, AdviceItem item){
  return ExpansionTile(
    title: Text(item.text),
    subtitle: Text(item.kind.toUpperCase() + ' • ' + item.confidence),
    children: [Padding(
      padding: const EdgeInsets.only(left:16, right:16, bottom:12),
      child: Text('Why: ' + item.why),
    )],
  );
}
