
import 'package:flutter/material.dart';
import 'package:collection/collection.dart';
import '../services/db.dart';

class HabitsScreen extends StatefulWidget{
  const HabitsScreen({super.key});
  @override State<HabitsScreen> createState()=> _HabitsScreenState();
}
class _HabitsScreenState extends State<HabitsScreen>{
  List<Map<String,dynamic>> habits = [];
  DateTime today = DateTime.now();

  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async { habits = await AppDatabase.instance.allHabits(); setState((){}); }

  Future<void> _addOrEdit({Map<String,dynamic>? h}) async {
    final nameCtrl = TextEditingController(text: h?['name'] ?? '');
    final goalCtrl = TextEditingController(text: ((h?['goal_per_week']) ?? 5).toString());
    await showDialog(context: context, builder:(_)=> AlertDialog(
      title: Text(h==null? 'New habit' : 'Edit habit'),
      content: Column(mainAxisSize: MainAxisSize.min, children:[
        TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Name')),
        const SizedBox(height:8),
        TextField(controller: goalCtrl, decoration: const InputDecoration(labelText: 'Goal per week'), keyboardType: TextInputType.number),
      ]),
      actions: [
        TextButton(onPressed: ()=> Navigator.pop(context), child: const Text('Cancel')),
        if (h!=null) TextButton(onPressed: () async { await AppDatabase.instance.deleteHabit(h['id']); if (mounted) Navigator.pop(context); await _load(); }, child: const Text('Delete')),
        FilledButton(onPressed: () async {
          final name = nameCtrl.text.trim(); final goal = int.tryParse(goalCtrl.text.trim()) ?? 5;
          if (name.isEmpty) return;
          final id = h?['id'] ?? DateTime.now().millisecondsSinceEpoch.toString();
          await AppDatabase.instance.upsertHabit(id, name, goalPerWeek: goal);
          if (mounted) Navigator.pop(context); await _load();
        }, child: const Text('Save')),
      ],
    ));
  }

  Future<void> _toggleDay(String habitId, DateTime day, bool done) async {
    await AppDatabase.instance.setHabitLog(habitId, day, done);
    await _load();
  }

  @override Widget build(BuildContext c){
    final weekStart = today.subtract(Duration(days: today.weekday - 1));
    final days = List.generate(7, (i)=> DateTime(weekStart.year, weekStart.month, weekStart.day + i));
    return Scaffold(appBar: AppBar(title: const Text('Habits'), actions:[
      IconButton(icon: const Icon(Icons.add), onPressed: ()=> _addOrEdit()),
    ]),
    body: ListView(padding: const EdgeInsets.all(12), children:[
      for (final h in habits) _HabitCard(habit: h, days: days, onToggle: _toggleDay, onEdit: ()=> _addOrEdit(h: h)),
    ]));
  }
}

class _HabitCard extends StatefulWidget{
  final Map<String,dynamic> habit;
  final List<DateTime> days;
  final Future<void> Function(String id, DateTime day, bool done) onToggle;
  final VoidCallback onEdit;
  const _HabitCard({required this.habit, required this.days, required this.onToggle, required this.onEdit});
  @override State<_HabitCard> createState()=> _HabitCardState();
}
class _HabitCardState extends State<_HabitCard>{
  Set<String> done = <String>{};

  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async { done = await AppDatabase.instance.habitDays(widget.habit['id']); setState((){}); }

  int _streakUpTo(DateTime day){
    int s=0; DateTime d = DateTime(day.year, day.month, day.day);
    while (true){
      final key = '${d.year}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')}';
      if (done.contains(key)){ s+=1; d = d.subtract(const Duration(days:1)); } else { break; }
    }
    return s;
  }

  @override Widget build(BuildContext c){
    final id = widget.habit['id']; final name = widget.habit['name']; final goal = (widget.habit['goal_per_week'] ?? 5) as int;
    final completed = widget.days.where((d){
      final key = '${d.year}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')}';
      return done.contains(key);
    }).length;
    final pct = (completed/goal*100).clamp(0,100).toDouble();
    final today = DateTime.now();
    final streak = _streakUpTo(today);

    return Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
      Row(children:[
        Expanded(child: Text(name ?? 'Habit', style: const TextStyle(fontWeight: FontWeight.bold))),
        IconButton(onPressed: widget.onEdit, icon: const Icon(Icons.edit)),
      ]),
      const SizedBox(height:4),
      Text('Goal: $goal / week   •   Completed: $completed   •   Adherence: ${pct.toStringAsFixed(0)}%   •   Streak: $streak'),
      const SizedBox(height:8),
      SizedBox.shrink(),
    ])));
  }
}
