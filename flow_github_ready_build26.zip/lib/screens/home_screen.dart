
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/db.dart';
import '../models/journal_entry.dart';
import '../services/prompts.dart';
import 'entry_screen.dart';
import 'analytics_screen.dart';
import 'import_export_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<JournalEntry> _recent = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final all = await AppDatabase.instance.all();
    setState(() => _recent = all.reversed.take(7).toList());
  }

  @override
  Widget build(BuildContext context) {
    final prompt = PromptEngine.pickPrompt(_recent);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Supreme'),
        actions: [
          IconButton(icon: const Icon(Icons.insights), onPressed: ()=> Navigator.push(context, MaterialPageRoute(builder: (_)=> const AnalyticsScreen()))),
          IconButton(icon: const Icon(Icons.import_export), onPressed: ()=> Navigator.push(context, MaterialPageRoute(builder: (_)=> const ImportExportScreen()))),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_)=> const EntryScreen()));
          await _load();
        },
        label: const Text('New Entry'),
        icon: const Icon(Icons.add),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              child: ListTile(
                title: const Text('Today’s prompt'),
                subtitle: Text(prompt),
                trailing: const Icon(Icons.edit),
                onTap: () async {
                  await Navigator.push(context, MaterialPageRoute(builder: (_)=> const EntryScreen()));
                  await _load();
                },
              ),
            ),
            const SizedBox(height: 8),
            const Text('Recent entries', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Expanded(
              child: _recent.isEmpty ? const Center(child: Text('No entries yet.')) :
              ListView.builder(
                itemCount: _recent.length,
                itemBuilder: (_, i) {
                  final e = _recent[i];
                  final dt = DateFormat('EEE, d MMM yyyy – HH:mm').format(e.dateTime);
                  return Card(
                    child: ListTile(
                      title: Text(dt),
                      subtitle: Text(e.text.isEmpty ? '(no text)' : (e.text.length>120? e.text.substring(0,120)+'…' : e.text)),
                      trailing: Text('M${e.mood}/E${e.energy}/F${e.focus}/L${e. style: const TextStyle(fontSize: 12)),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
