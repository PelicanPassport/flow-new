
import 'package:flutter/material.dart';
import '../services/db.dart';
import '../services/analytics.dart';
import '../models/journal_entry.dart';
import 'package:intl/intl.dart';

class AnalyticsScreen extends StatefulWidget {
  const AnalyticsScreen({super.key});
  @override
  State<AnalyticsScreen> createState() => _AnalyticsScreenState();
}

class _AnalyticsScreenState extends State<AnalyticsScreen> {
  List<JournalEntry> all = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final entries = await AppDatabase.instance.all();
    setState(() => all = entries);
  }

  @override
  Widget build(BuildContext context) {
    final weekly = Analytics.weeklyAverages(all);
    final slopes = Analytics.trendSlopes30d(all);
    final anomalies = Analytics.anomalies(all);

    return Scaffold(
      appBar: AppBar(title: const Text('Analytics')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            Card(child: ListTile(
              title: const Text('This week (avg)'),
              subtitle: Text('Mood ${weekly['mood']?.toStringAsFixed(1) ?? '-'} • '
                  'Energy ${weekly['energy']?.toStringAsFixed(1) ?? '-'} • '
                  'Focus ${weekly['focus']?.toStringAsFixed(1) ?? '-'} • '
                  'Libido ${weekly[') ?? '-'}'),
            )),
            const SizedBox(height: 8),
            Card(child: ListTile(
              title: const Text('30‑day trend (slope)'),
              subtitle: Text('Mood ${slopes['mood']?.toStringAsFixed(2)} • '
                  'Energy ${slopes['energy']?.toStringAsFixed(2)} • '
                  'Focus ${slopes['focus']?.toStringAsFixed(2)} • '
                  'Libido ${slopes[')}'),
            )),
            const SizedBox(height: 8),
            if (anomalies.isNotEmpty) Card(
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Anomalies', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    ...anomalies.map((a)=> Text('• $a')),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            Card(child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Recent entries', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  ...all.reversed.take(10).map((e){
                    final dt = DateFormat('d MMM HH:mm').format(e.dateTime);
                    return Text('$dt  M${e.mood}/E${e.energy}/F${e.focus}/L${e.);
                  }),
                ],
              ),
            )),
          ],
        ),
      ),
    );
  }
}
