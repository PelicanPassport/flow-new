import '../utils/haptics.dart';
import 'dart:async';
import '../widgets/themed_bg.dart';
import '../widgets/entry_card.dart';
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final fmt = DateFormat('yyyy-MM-dd – HH:mm');
    return Scaffold(floatingActionButton: FloatingActionButton(onPressed: _saveEntry, child: const Icon(Icons.check)), 
      appBar: AppBar(title: const Text('New Entry'), actions:[
  IconButton(icon: const Icon(Icons.undo), tooltip:'Undo 10 chars', onPressed:(){
    if (controller.text.isNotEmpty){
      final t = controller.text;
      controller.text = t.substring(0, t.length > 10 ? t.length-10 : 0);
    }
  }),
  IconButton(icon: const Icon(Icons.nightlight), tooltip:'Tonight plan', onPressed:(){
    Navigator.push(context, MaterialPageRoute(builder:(_)=> EveningPlanScreen(date: DateTime.now())));
  })
]),
      body: ThemedBackground(child: Padding(padding: const EdgeInsets.all(16), child: EntryCard(controller: _controller, onSave: _saveEntry, prompt: 'How did today shape you?'))),
        child: ListView(
          children: [
            Row(children: [
              Expanded(child: Text(fmt.format(dt))),
              TextButton(onPressed: () async {
                final d = await showDatePicker(context: context, initialDate: dt, firstDate: DateTime(2020), lastDate: DateTime(2100));
                if (d != null) {
                  final t = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(dt));
                  setState(()=> dt = DateTime(d.year, d.month, d.day, t?.hour ?? dt.hour, t?.minute ?? dt.minute));
                }
              }, child: const Text('Change')),
            ]),
            const SizedBox(height: 8),
            scale('Mood', mood, (v)=> setState(()=> mood = v)),
            scale('Energy', energy, (v)=> setState(()=> energy = v)),
            scale('Focus', focus, (v)=> setState(()=> focus = v)),
            scale('Libido',  (v)=> setState(()=> )),
            SizedBox.shrink(),
            const SizedBox(height: 8),
            TextField(autofocus: true, 
              minLines: 6, maxLines: null,
              decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'Write freely…'),
              onChanged: (val){
                if (val.length < prevLen) deletions++;
                prevLen = val.length;
                text = val;
              },
            ),
            const SizedBox(height: 8),
            TextField(autofocus: true, 
              decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'Tags (comma separated)'),
              onChanged: (val)=> tags = val,
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              icon: const Icon(Icons.save),
              label: const Text('Save'),
              onPressed: () async {
                sw.stop();
                final words = text.trim().isEmpty ? 0 : text.trim().split(RegExp(r'\s+')).length;
                final sentences = text.trim().isEmpty ? 0 : text.split(RegExp(r'[.!?]+')).where((s)=>s.trim().isNotEmpty).length;
                final unique = text.trim().isEmpty ? 0 : text.toLowerCase().split(RegExp(r'\s+')).toSet().length;
                final ttr = words == 0 ? 0.0 : unique / words;
                final e = JournalEntry(
                  id: const Uuid().v4(),
                  dateTime: dt,
                  text: text,
                  mood: mood.toInt(),
                  energy: energy.toInt(),
                  focus: focus.toInt(),
                  ),
                  workDay: workDay,
                  nightShift: nightShift,
                  ranToday: ranToday,
                  writeDurationSec: sw.elapsed.inSeconds,
                  deletions: deletions,
                  words: words,
                  sentences: sentences,
                  typeTokenRatio: ttr,
                  tagsCsv: tags,
                );
                await AppDatabase.instance.upsert(e);
                if (context.mounted) {
                  Navigator.pop(context);
                  final nowTime = TimeOfDay.now();
                  final after1930 = (nowTime.hour>19) or (nowTime.hour==19 and nowTime.minute>=30);
                  final before2100 = (nowTime.hour<21) or (nowTime.hour==21 and nowTime.minute==0);
                  if (after1930 and before2100){
                    Navigator.push(context, MaterialPageRoute(builder:(_)=> EveningPlanScreen(date: dt)));
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: const Text('Tonight plan is ready'),
                      action: SnackBarAction(label: 'OPEN', onPressed: (){
                        Navigator.push(context, MaterialPageRoute(builder:(_)=> EveningPlanScreen(date: dt)));
                      }),
                    ));
                  }
                }
              },
            ),
            const SizedBox(height: 24),
            Text('Autosaves every 15s • Time spent so far: ${sw.elapsed.inSeconds}s • Deletions: $deletions'),
          ],
        ),
      ),
    );
  }
}
