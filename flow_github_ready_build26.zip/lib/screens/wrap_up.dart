
import 'package:flutter/material.dart';
import '../services/db.dart';
import '../models/models.dart';
import 'habits.dart';

class WrapUpFlow extends StatefulWidget{
  final DateTime date;
  const WrapUpFlow({super.key, required this.date});
  @override State<WrapUpFlow> createState()=> _WrapUpFlowState();
}

class _WrapUpFlowState extends State<WrapUpFlow>{
  int step = 0; // 0 = habits, 1 = games, 2 = summary
  int score = 50;

  @override Widget build(BuildContext c){
    return Scaffold(appBar: AppBar(title: const Text('Daily wrap‑up')), body: Padding(
      padding: const EdgeInsets.all(16),
      child: switch(step){
        0 => _HabitsCheck(onNext: ()=> setState(()=> step=1), date: widget.date),
        1 => _GamesMini(onDone: (s){ setState(()=> { score = s, step = 2 }); }),
        _ => _Summary(score: score),
      },
    ));
  }
}

class _HabitsCheck extends StatefulWidget{
  final VoidCallback onNext; final DateTime date;
  const _HabitsCheck({required this.onNext, required this.date});
  @override State<_HabitsCheck> createState()=> _HabitsCheckState();
}
class _HabitsCheckState extends State<_HabitsCheck>{
  List<Map<String,dynamic>> habits=[]; final toggled = <String,bool>{};
  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async{
    habits = await AppDatabase.instance.allHabits();
    setState((){});
  }
  Future<void> _toggle(String id, bool v) async {
    await AppDatabase.instance.setHabitLog(id, widget.date, v);
    setState(()=> toggled[id]=v);
  }
  @override Widget build(BuildContext c){
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
      const Text('Habits today', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height:8),
      Expanded(child: ListView(children:[
        for (final h in habits) CheckboxListTile(
          value: toggled[h['id']] ?? false,
          onChanged: (v)=> _toggle(h['id'], v ?? false),
          title: Text(h['name'] ?? 'Habit'),
          secondary: const Icon(Icons.check_circle_outline),
        )
      ])),
      Align(alignment: Alignment.centerRight, child: FilledButton(onPressed: widget.onNext, child: const Text('Next'))),
    ]);
  }
}

import '../games/pattern_recall.dart';
import '../games/reaction_tap.dart';
import '../games/tetris_slow.dart';
import '../services/telemetry.dart';

class _GamesMini extends StatefulWidget{
  final void Function(int) onDone;
  const _GamesMini({required this.onDone});
  @override State<_GamesMini> createState()=> _GamesMiniState();
}
class _GamesMiniState extends State<_GamesMini>{
  int elapsed = 0; int score = 50; late final DateTime start;
  @override void initState(){ super.initState(); start = DateTime.now(); _tick(); }
  void _tick() async {
    // Simulate a 3-minute rotation (here a 10-second fast demo). Replace with real games in production.
    await Future.delayed(const Duration(seconds: 10));
    if (!mounted) return;
    setState(()=> score = 50 + DateTime.now().second % 50);
    widget.onDone(score);
  }
  @override Widget build(BuildContext c){
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
      const Text('Cognitive mini‑session (~3 minutes)', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height:8),
      const Text('Today: Pattern recall + Reaction test + Tetris‑slow (rotation adapts daily).'),
      const Spacer(),
      const LinearProgressIndicator(),
      const SizedBox(height:8),
      const Text('Running…'),
    ]);
  }
}

class _Summary extends StatelessWidget{
  final int score;
  const _Summary({required this.score});
  @override Widget build(BuildContext c){
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
      const Text('Done!', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height:8),
      Text('Cognitive score today: $score'),
      const SizedBox(height:16),
      const Text('Tip: scores tend to improve with >7h sleep and a short wind‑down.'),
      const Spacer(),
      Align(alignment: Alignment.centerRight, child: FilledButton(onPressed: ()=> Navigator.pop(c), child: const Text('Finish'))),
    ]);
  }
}
