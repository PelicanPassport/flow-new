
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/db.dart';
import '../services/search.dart';
import '../models/models.dart';
import 'daily_detail.dart';
import 'reports.dart';
import 'calendar.dart';

class SearchScreen extends StatefulWidget{ const SearchScreen({super.key}); @override State<SearchScreen> createState()=> _SearchScreenState(); }
class _SearchScreenState extends State<SearchScreen>{
  final List<String> saved = [];
  List<JournalEntry> all = []; List<JournalEntry> results = [];
  final ctrl = TextEditingController(); final _fmt = DateFormat('yyyy-MM-dd'); bool searching=false;

  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async { all = await AppDatabase.instance.all(); setState(()=> results = all.reversed.take(20).toList()); }
  Future<void> _doSearch(String q) async { setState(()=> searching=true); await Future.delayed(const Duration(milliseconds: 50)); final res = JournalSearch.search(all, q, topK: 50); if (mounted) setState(()=> { results = res, searching=false }); }
  void _applyQuick(String frag){ final cur = ctrl.text.trim(); final next = cur.isEmpty? frag : (cur + ' ' + frag); ctrl.text = next; _doSearch(next); }
  Widget _snippet(String text, String q){ final s = JournalSearch.snippet(text, q); return Text(s, maxLines: 3, overflow: TextOverflow.ellipsis); }

  @override Widget build(BuildContext c){
    return Scaffold(appBar: AppBar(title: const Text('Search')), body: Padding(padding: const EdgeInsets.all(16), child: Column(children:[
      TextField(controller: ctrl, onChanged: _doSearch, decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search + filters (e.g., night:true mood:>=6 "wind down")', border: OutlineInputBorder())),
      const SizedBox(height:8),
      SizedBox.shrink(),
      const SizedBox(height:8),
      if (searching) const LinearProgressIndicator(),
      Expanded(child: Column(children:[ if (saved.isNotEmpty) Align(alignment: Alignment.centerLeft, child: SizedBox.shrink()), const SizedBox(height:8), Expanded(child: ListView.builder(itemCount: results.length, itemBuilder: (_,i){
        final e = results[i]; final d = DateTime(e.dateTime.year,e.dateTime.month,e.dateTime.day);
        return Card(child: Column(children:[
          ListTile(
            title: Text('${e.dateTime.toString().substring(0,16)}  •  M${e.mood}/E${e.energy}/S${e.stress}'),
            subtitle: e.text.isEmpty? const Text('(no text)') : _snippet(e.text, ctrl.text),
            onTap: ()=> Navigator.push(c, MaterialPageRoute(builder:(_)=> DailyDetail(date: d))),
          ),
          Padding(padding: const EdgeInsets.fromLTRB(12,0,12,12), child: Row(children:[
            TextButton.icon(onPressed: ()=> Navigator.push(c, MaterialPageRoute(builder:(_)=> DailyDetail(date: d))), icon: const Icon(Icons.today, size:16), label: const Text('Day')),
            const SizedBox(width:8),
            TextButton.icon(onPressed: ()=> Navigator.push(c, MaterialPageRoute(builder:(_)=> ReportsScreen(focusDate: d))), icon: const Icon(Icons.view_week, size:16), label: const Text('Week')),
            const SizedBox(width:8),
            TextButton.icon(onPressed: ()=> Navigator.push(c, MaterialPageRoute(builder:(_)=> const MonthView())), icon: const Icon(Icons.calendar_month, size:16), label: const Text('Month')),
          ])),
        ]));
      }))
    ])));
  }
}
