import '../services/habit_plateau.dart';
import '../services/experiments_service.dart';

import 'package:flutter/material.dart';
import '../services/insight_weights.dart';

class WeeklyDigest extends StatelessWidget{
  final List<String> bullets;
  const WeeklyDigest({super.key, required this.bullets});

  @override Widget build(BuildContext context){
    final items = bullets.take(3).toList();
    return Scaffold(appBar: AppBar(title: const Text('Weekly Digest')), body: ListView.separated(
      itemCount: items.length,
      separatorBuilder: (_, __)=> const Divider(height:1),
      itemBuilder: (context, i){
        final b = items[i];
        return ListTile(
          title: Text(b),
          subtitle: Row(children:[
            const Text('Confidence: '), Chip(label: Text(_confidenceFor(b))),
          ]),
          trailing: Wrap(spacing: 8, children: [
            IconButton(icon: const Icon(Icons.thumb_up_alt_outlined), onPressed: ()=> InsightWeights.vote('digest_$i', +1)),
            IconButton(icon: const Icon(Icons.thumb_down_alt_outlined), onPressed: ()=> InsightWeights.vote('digest_$i', -1)),
            TextButton(onPressed: ()=> _addToPlan(context, b), child: const Text('Add to plan')),
          ]),
        );
      },
    ));
  }

  String _confidenceFor(String text){
    // naive tag detection for demo; real app passes confidence from engine
    if (text.contains('[High]')) return 'High';
    if (text.contains('[Medium]')) return 'Medium';
    return 'Low';
  }

  void _addToPlan(BuildContext context, String text){
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Added to tomorrow plan: '+text)));
  }
}


/* WEEKLY_EXTRAS */
class ExperimentBanner extends StatelessWidget{
  final MicroExperiment exp;
  final VoidCallback onDismiss;
  const ExperimentBanner({super.key, required this.exp, required this.onDismiss});
  @override Widget build(BuildContext context){
    return Card(color: Theme.of(context).colorScheme.secondaryContainer, child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Learning week: '+exp.title, style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height:6),
        Text('Tonight: '+exp.tonightAction),
        const SizedBox(height:8),
        Wrap(children:[
          TextButton(onPressed: onDismiss, child: const Text('Dismiss')), 
        ])
      ]),
    ));
  }
}

class PlateauTile extends StatelessWidget{
  final HabitImpact impact;
  const PlateauTile({super.key, required this.impact});
  @override Widget build(BuildContext context){
    final d = ((impact.recentImpact - impact.priorImpact)/((impact.priorImpact.abs()+0.0001))).toStringAsFixed(0);
    return ListTile(
      title: Text('Habit: '+impact.habit),
      subtitle: Text(impact.plateau ? 'Impact down ~${d}% (possible plateau)' : 'Impact holding steady'),
      leading: Icon(impact.plateau ? Icons.trending_down : Icons.trending_flat),
    );
  }
}
