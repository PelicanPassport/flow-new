
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:file_picker/file_picker.dart';
import '../services/db.dart';
import '../models/models.dart';
import '../services/drive_backup.dart';

class IOPage extends StatefulWidget{ const IOPage({super.key}); @override State<IOPage> createState()=> _IOPageState(); }
class _IOPageState extends State<IOPage>{
  final txt = TextEditingController();
  bool _auto = true; TimeOfDay _time = const TimeOfDay(hour: 2, minute: 0);
  List<Map<String,String>> _driveFiles = [];
  final txt = TextEditingController();
  String status = '';

  Future<void> _exportJsonl() async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/supreme_export.jsonl');
    final xs = await AppDatabase.instance.all();
    final sink = file.openWrite();
    for (final e in xs){
      final m = {
        'id': e.id,
        'date': e.dateTime.toIso8601String(),
        'mood': e.mood, 'energy': e.energy, 'stress': e.stress,
        'words': e.words, 'wpm': e.wordsPerMinute, 'deletions': e.deletions,
        'work': e.workDay, 'night': e.nightShift, 'ran': e.ranToday,
        'text': e.text,
      };
      sink.writeln(jsonEncode(m));
    }
    await sink.close();
    setState(()=> status = 'Exported to ' + file.path);
  }

  @override Widget build(BuildContext c){
    return Scaffold(appBar: AppBar(title: const Text('Import / Export')), body: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
        const Text('Export'), const SizedBox(height:8),
        FilledButton(onPressed: _exportJsonl, child: const Text('Export JSONL (Supreme schema)')),
        const SizedBox(height:16),
        Text(status), const Divider(), const Text('Cloud Backup'), const SizedBox(height:8), FilledButton.icon(onPressed: () async { setState(()=> status='Working…'); final msg = await DriveBackup.backupNow(); if (mounted) setState(()=> status = 'Drive: ' + msg); }, icon: const Icon(Icons.cloud_upload), label: const Text('One‑tap Google Drive Backup')), const SizedBox(height:16), const SizedBox(height:8), FilledButton.icon(onPressed: _pickCsv, icon: const Icon(Icons.file_open), label: const Text('Import CSV from file')), const Divider(), const Text('Import'), const SizedBox(height:8), TextField(controller: txt, decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'Paste CSV rows here (id,date,mood,energy,stress,words,wpm,deletions,work,night,ran,text)')), const SizedBox(height:8), FilledButton(onPressed: _importCsv, child: const Text('Import CSV (paste)')),
      ]),
    ));
  }
}


  Future<void> _importCsv() async {
    final lines = txt.text.trim().split(RegExp(r'\r?\n'));
    int ok=0, fail=0;
    for (final line in lines){
      if (line.trim().isEmpty) continue;
      final parts = _csvSplit(line);
      if (parts.length < 12){ fail+=1; continue; }
      try{
        final e = JournalEntry(
          id: parts[0],
          dateTime: DateTime.parse(parts[1]),
          mood: int.parse(parts[2]), energy: int.parse(parts[3]), stress: int.parse(parts[4]),
          words: int.parse(parts[5]), wordsPerMinute: parts[6].isEmpty? null : double.tryParse(parts[6]), deletions: int.parse(parts[7]),
          workDay: parts[8].toLowerCase()=='true', nightShift: parts[9].toLowerCase()=='true', ranToday: parts[10].toLowerCase()=='true',
          text: parts.sublist(11).join(','), // allow commas in text
        );
        await AppDatabase.instance.insert(e); ok+=1;
      } catch(_){ fail+=1; }
    }
    setState(()=> status = 'Imported $ok rows, $fail failed.');
  }

  List<String> _csvSplit(String s){
    final out=<String>[]; final buf=StringBuffer(); bool inQ=false;
    for (int i=0;i<s.length;i++){
      final ch=s[i];
      if (ch=='"'){ inQ = !inQ; }
      else if (ch==',' && !inQ){ out.add(buf.toString()); buf.clear(); }
      else { buf.write(ch); }
    }
    out.add(buf.toString());
    return out;
  }


  Future<void> _pickCsv() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['csv','txt']);
    if (res==null || res.files.isEmpty) return;
    final path = res.files.single.path;
    if (path==null) return;
    final file = File(path);
    final content = await file.readAsString();
    txt.text = content;
    await _importCsv();
  }
