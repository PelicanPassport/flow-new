
import 'package:flutter/material.dart';
import '../services/db.dart';
import '../models/models.dart';
import 'daily_detail.dart';

class MonthView extends StatefulWidget{ const MonthView({super.key}); @override State<MonthView> createState()=> _MonthViewState(); }
class _MonthViewState extends State<MonthView>{
  List<JournalEntry> all = []; DateTime focus = DateTime(DateTime.now().year, DateTime.now().month, 1);
  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async { all = await AppDatabase.instance.all(); setState((){}); }

  @override Widget build(BuildContext c){
    final firstWeekday = DateTime(focus.year, focus.month, 1).weekday; // 1=Mon
    final daysInMonth = DateTime(focus.year, focus.month + 1, 0).day;
    final cellsBefore = (firstWeekday - 1) % 7;
    final totalCells = cellsBefore + daysInMonth;
    final weeks = (totalCells / 7).ceil();
    final items = List.generate(weeks*7, (i){
      final dayNum = i - cellsBefore + 1;
      if (dayNum < 1 || dayNum > daysInMonth) return SizedBox.shrink();
      final date = DateTime(focus.year, focus.month, dayNum);
      final entries = all.where((e)=> e.dateTime.year==date.year && e.dateTime.month==date.month && e.dateTime.day==date.day).toList();
      double? mood;
      int words = entries.isEmpty?0: entries.map((e)=> e.words).reduce((a,b)=> a+b);
      if (entries.isNotEmpty){ mood = entries.map((e)=> e.mood).reduce((a,b)=> a+b) / entries.length; }
      final hasNight = entries.any((e)=> e.nightShift);
      final ran = entries.any((e)=> e.ranToday);
      return InkWell(onTap: ()=> Navigator.push(c, MaterialPageRoute(builder:(_)=> DailyDetail(date: date))), child:
        Container(margin: const EdgeInsets.all(2), padding: const EdgeInsets.all(6), decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.grey.shade300), color: _heat(words)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
            Row(children:[ Text('$dayNum', style: const TextStyle(fontWeight: FontWeight.bold)), const Spacer(), if (hasNight) const Icon(Icons.nightlight_round, size:14), if (ran) const Icon(Icons.directions_run, size:14) ]),
            const Spacer(),
            Align(alignment: Alignment.bottomLeft, child: Container(width:12, height:12, decoration: BoxDecoration(color: _moodColor(mood), shape: BoxShape.circle))),
          ])));
    });

    return Scaffold(appBar: AppBar(title: Text('${focus.year}-${focus.month.toString().padLeft(2,'0')}'), actions: [
      IconButton(icon: const Icon(Icons.chevron_left), onPressed: ()=> setState(()=> focus = DateTime(focus.year, focus.month-1, 1))),
      IconButton(icon: const Icon(Icons.chevron_right), onPressed: ()=> setState(()=> focus = DateTime(focus.year, focus.month+1, 1))),
    ]),
      body: Padding(padding: const EdgeInsets.all(12), child: Column(children:[
        SizedBox.shrink(), const SizedBox(height:8),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: const [ Text('Mon'), Text('Tue'), Text('Wed'), Text('Thu'), Text('Fri'), Text('Sat'), Text('Sun') ]),
        const SizedBox(height:8),
        Expanded(child: GridView.count(crossAxisCount: 7, children: items)),
      ])));
  }

  Color _moodColor(double? m){
    if (m==null) return Colors.grey.shade300;
    if (m >= 7) return Colors.teal;
    if (m >= 5) return Colors.teal.shade200;
    if (m >= 3) return Colors.orange.shade300;
    return Colors.orange;
  }
}


  Color _heat(int words){
    if (words<=0) return Colors.transparent;
    if (words<50) return Colors.teal.withOpacity(0.10);
    if (words<150) return Colors.teal.withOpacity(0.18);
    if (words<300) return Colors.teal.withOpacity(0.26);
    return Colors.teal.withOpacity(0.34);
  }
