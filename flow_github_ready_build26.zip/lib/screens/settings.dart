
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeChoice { final String key; final String name; final Color seed; ThemeChoice(this.key, this.name, this.seed); }

final themeChoices = <ThemeChoice>[
  ThemeChoice('pastel_green','Pastel Green', const Color(0xFFCFF5D0)),
  ThemeChoice('soft_blue','Soft Blue', const Color(0xFFD1ECFF)),
  ThemeChoice('warm_sand','Warm Sand', const Color(0xFFF6E6C8)),
  ThemeChoice('slate_grey','Slate Grey', const Color(0xFFB0BEC5)),
  ThemeChoice('lavender_mist','Lavender Mist', const Color(0xFFE6DFFF)),
  ThemeChoice('forest_mint','Forest Mint', const Color(0xFFBFECD6)),
  ThemeChoice('ocean_teal','Ocean Teal', const Color(0xFFBDEFEA)),
  ThemeChoice('sunset_coral','Sunset Coral', const Color(0xFFFFD9D2)),
  ThemeChoice('amber_dawn','Amber Dawn', const Color(0xFFFFEDC2)),
  ThemeChoice('rose_quartz','Rose Quartz', const Color(0xFFF9D7E3)),
];

typedef ThemeApply = void Function(ThemeChoice);

class SettingsScreen extends StatefulWidget {
  final ThemeApply onApplyTheme;
  const SettingsScreen({super.key, required this.onApplyTheme});
  @override State<SettingsScreen> createState()=> _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen>{
  String current = 'pastel_green';
  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async{
    final sp = await SharedPreferences.getInstance();
    setState(()=> current = sp.getString('theme_key') ?? 'pastel_green');
  }
  Future<void> _save(String k) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString('theme_key', k);
  }
  @override Widget build(BuildContext context){
    return Scaffold(appBar: AppBar(title: const Text('Settings')), body: ListView(
      children: [
        const ListTile(title: Text('Backup')), ListTile(title: const Text('Last backup'), subtitle: Text(_lastBackupText)),
        const SizedBox(height:12),
        const ListTile(title: Text('Advice frequency')),
        _AdviceLevelTile(title:'High (more talkative)', levelKey:'high'),
        _AdviceLevelTile(title:'Balanced (recommended)', levelKey:'balanced'),
        _AdviceLevelTile(title:'Low (only big changes)', levelKey:'low'),
        SwitchListTile(title: const Text('Learning weeks (micro-experiments)'), value: true, onChanged: (v){}),
        const ListTile(title: Text('Theme')),
        for (final ch in themeChoices) RadioListTile<String>(
          value: ch.key, groupValue: current, title: Text(ch.name),
          onChanged: (v){ if (v==null) return; setState(()=> current=v); _save(v); widget.onApplyTheme(ch); },
        ),
      ],
    ));
  }
}


class _AdviceLevelTile extends StatefulWidget{
  final String title;
  final String levelKey;
  const _AdviceLevelTile({required this.title, required this.levelKey});
  @override State<_AdviceLevelTile> createState()=> _AdviceLevelTileState();
}
class _AdviceLevelTileState extends State<_AdviceLevelTile>{
  String _cur = 'balanced';
  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async{
    final sp = await SharedPreferences.getInstance();
    setState(()=> _cur = sp.getString('advice_level') ?? 'balanced');
  }
  Future<void> _save(String v) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString('advice_level', v);
  }
  @override Widget build(BuildContext context){
    return RadioListTile<String>(title: Text(widget.title), value: widget.levelKey, groupValue: _cur, onChanged: (v){ if(v==null) return; setState(()=> _cur=v); _save(v); });
  }
}
