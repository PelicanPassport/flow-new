
import 'package:flutter/services.dart';

class Haptics {
  static Future<void> tap() async {
    try{ await HapticFeedback.selectionClick(); } catch(_){}
  }
  static Future<void> success() async {
    try{ await HapticFeedback.lightImpact(); } catch(_){}
  }
}
