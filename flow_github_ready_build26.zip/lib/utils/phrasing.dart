
import 'dart:math';

class Phrasing {
  static final _rand = Random();
  static String oneOf(List<String> options){
    if (options.isEmpty) return '';
    return options[_rand.nextInt(options.length)];
  }
  static String reinforcement(){
    return oneOf([
      'Nice consistency—keep leaning into what works.',
      'Solid progress lately. Small steps, same direction.',
      'You’re building momentum. Protect the basics that help you.',
      'Good work—your routines are paying off.'
    ]);
  }
}
