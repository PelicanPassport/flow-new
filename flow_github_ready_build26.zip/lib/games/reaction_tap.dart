
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

class ReactionTapGame extends StatefulWidget{
  final void Function(int score) onDone;
  const ReactionTapGame({super.key, required this.onDone});
  @override State<ReactionTapGame> createState()=> _ReactionTapGameState();
}
class _ReactionTapGameState extends State<ReactionTapGame>{
  String state = 'wait'; // wait -> ready -> tap
  int bestMs = 9999; int lastMs = 0; Timer? _t; late int start;
  final rnd = Random();

  void _start(){
    setState(()=> state='ready');
    _t?.cancel();
    _t = Timer(Duration(milliseconds: 800 + rnd.nextInt(1200)), (){
      setState(()=> state='tap'); start = DateTime.now().millisecondsSinceEpoch;
    });
  }
  void _tap(){
    if (state!='tap') return;
    lastMs = DateTime.now().millisecondsSinceEpoch - start;
    if (lastMs < bestMs) bestMs = lastMs;
    if (bestMs < 250){ widget.onDone(100 - bestMs~/3); } else { _start(); }
    setState((){});
  }
  @override void initState(){ super.initState(); _start(); }
  @override void dispose(){ _t?.cancel(); super.dispose(); }

  @override Widget build(BuildContext c){
    return Column(children:[
      const Text('Reaction Tap', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height:8),
      Expanded(child: Center(child: GestureDetector(
        onTap: _tap,
        child: Container(width: 240, height: 240, decoration: BoxDecoration(
          color: state=='tap'? Colors.teal : Colors.grey.shade400, borderRadius: BorderRadius.circular(16)),
          child: Center(child: Text(state=='tap'? 'TAP!' : 'Wait…', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
        ),
      ))),
      Text('Best: ${bestMs==9999?'-':bestMs.toString()+' ms'}  •  Last: ${lastMs==0?'-':lastMs.toString()+' ms'}'),
    ]);
  }
}
