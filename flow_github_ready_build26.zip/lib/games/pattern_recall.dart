
import 'dart:async';
import 'package:flutter/material.dart';

class PatternRecallGame extends StatefulWidget{
  final void Function(int score) onDone;
  const PatternRecallGame({super.key, required this.onDone});
  @override State<PatternRecallGame> createState()=> _PatternRecallGameState();
}
class _PatternRecallGameState extends State<PatternRecallGame>{
  final grid = List.generate(9, (i)=> i); // 3x3
  List<int> seq = []; List<int> input = [];
  int phase = 0; // 0 show, 1 input, 2 done
  int round = 0; int score = 0;
  Timer? _timer; int idx=0;

  @override void initState(){ super.initState(); _nextRound(); }
  void _nextRound(){
    round += 1;
    input.clear();
    seq.add((DateTime.now().millisecondsSinceEpoch + round) % 9);
    idx = 0; phase = 0; setState((){});
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(milliseconds: 700), (t){
      if (idx >= seq.length){ t.cancel(); setState(()=> phase=1); return; }
      setState(()=> idx++);
    });
  }

  void _tap(int i){
    if (phase!=1) return;
    input.add(i);
    if (input.length == seq.length){
      bool ok = true;
      for (int k=0;k<seq.length;k++){ if (seq[k]!=input[k]){ ok=false; break; } }
      if (ok){ score += 10*round; if (round>=5){ _finish(); } else { _nextRound(); } }
      else { _finish(); }
    }
  }

  void _finish(){ phase=2; _timer?.cancel(); widget.onDone(score); }

  @override void dispose(){ _timer?.cancel(); super.dispose(); }

  @override Widget build(BuildContext c){
    return Column(children:[
      Text('Pattern Recall — Round $round', style: const TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height:8),
      AspectRatio(aspectRatio: 1, child: GridView.count(crossAxisCount: 3, children:[
        for (int i=0;i<9;i++)
          GestureDetector(
            onTap: ()=> _tap(i),
            child: Container(margin: const EdgeInsets.all(6), decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: (phase==0 && idx>0 && i==seq[idx-1]) ? Colors.teal : Colors.grey.shade300,
            )),
          )
      ])),
      Text(phase==0? 'Watch the sequence' : phase==1? 'Repeat the sequence' : 'Done'),
    ]);
  }
}
