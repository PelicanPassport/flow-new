
import 'dart:async';
import 'package:flutter/material.dart';

class TetrisSlowGame extends StatefulWidget{
  final void Function(int score) onDone;
  const TetrisSlowGame({super.key, required this.onDone});
  @override State<TetrisSlowGame> createState()=> _TetrisSlowGameState();
}
class _TetrisSlowGameState extends State<TetrisSlowGame>{
  static const w=6, h=12;
  List<List<int>> grid = List.generate(h, (_)=> List.filled(w, 0));
  int x=2, y=0, score=0; Timer? _timer; bool running=true;

  @override void initState(){ super.initState(); _timer = Timer.periodic(const Duration(milliseconds: 600), (_){ _tick(); }); }
  @override void dispose(){ _timer?.cancel(); super.dispose(); }

  void _tick(){
    if (!running) return;
    if (y+1>=h || grid[y+1][x]==1){ grid[y][x]=1; score+=5; y=0; x=2; if (grid[0][2]==1){ running=false; widget.onDone(score); } }
    else { y+=1; }
    setState((){});
  }
  void _move(int dx){
    if (!running) return;
    if (x+dx>=0 && x+dx<w && grid[y][x+dx]==0) setState(()=> x+=dx);
  }

  @override Widget build(BuildContext c){
    return Column(children:[
      const Text('Tetris Slow (calm mode)', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height:8),
      AspectRatio(aspectRatio: w/h, child: Container(
        decoration: BoxDecoration(border: Border.all(color: Colors.grey.shade400), borderRadius: BorderRadius.circular(8)),
        child: Stack(children:[
          for (int r=0;r<h;r++) for (int c=0;c<w;c++)
            Positioned(left: c*(MediaQuery.of(c).size.width/(w*2)), top: r*(MediaQuery.of(c).size.width/(w*2)),
              child: Container(width: 18, height: 18, margin: const EdgeInsets.all(2),
                decoration: BoxDecoration(color: grid[r][c]==1? Colors.teal : Colors.grey.shade300, borderRadius: BorderRadius.circular(4)))),
          Positioned(left: x*(MediaQuery.of(c).size.width/(w*2)), top: y*(MediaQuery.of(c).size.width/(w*2)),
              child: Container(width: 18, height: 18, margin: const EdgeInsets.all(2),
                decoration: BoxDecoration(color: Colors.teal.shade200, borderRadius: BorderRadius.circular(4)))),
        ]),
      )),
      const SizedBox(height:8),
      Row(mainAxisAlignment: MainAxisAlignment.center, children:[
        IconButton(onPressed: ()=> _move(-1), icon: const Icon(Icons.chevron_left)),
        const SizedBox(width:12),
        IconButton(onPressed: ()=> _move(1), icon: const Icon(Icons.chevron_right)),
      ]),
      Text('Score: $score'),
    ]);
  }
}
