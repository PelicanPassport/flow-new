import '../utils/phrasing.dart';

import 'advice_policy.dart';

class AdviceItem {
  final String key;      // stable identifier of the insight for cooldown
  final String text;     // phrased advice
  final String why;      // short explanation
  final String kind;     // 'reactive' | 'predictive' | 'positive'
  final String confidence; // 'Low' | 'Medium' | 'High'
  AdviceItem({required this.key, required this.text, required this.why, required this.kind, required this.confidence});
}

class AdviceEngineResult {
  final List<AdviceItem> tonight;
  final List<AdviceItem> nextDays;
  AdviceEngineResult({required this.tonight, required this.nextDays});
}

Future<AdviceEngineResult> generateAdviceDemo({required bool isRareBadDay, required Map<String,double> deltas}) async {
  // deltas: e.g., {'mood': -0.2, 'energy': -0.15} compared to baseline
  final lv = await AdvicePolicy.level();
  final List<AdviceItem> tonight = [];
  final List<AdviceItem> nextDays = [];

  bool significantDrop(String metric, double thr){
    final v = deltas[metric] ?? 0.0;
    return v <= -thr; // drop beyond threshold
  }

  // Reactive: only on bad days or significant changes
  if (isRareBadDay || significantDrop('mood', lv==AdviceLevel.low?0.25:lv==AdviceLevel.high?0.1:0.15)){
    final key = 'calm_winddown';
    if (!await AdvicePolicy.isOnCooldown(key)){
      tonight.add(AdviceItem(
        key: key,
        text: Phrasing.oneOf(['Keep the evening light and calm.', 'Wind things down gently tonight.']),
        why: 'Mood dipped vs your normal; calmer evenings tend to help you recover.',
        kind: 'reactive',
        confidence: 'Medium'
      ));
      await AdvicePolicy.markShown(key);
    }
  }

  // Predictive: always include a light preview
  nextDays.add(AdviceItem(
    key: 'tomorrow_preview',
    text: Phrasing.oneOf(['Tomorrow looks like a better focus window before late morning.', 'Aim your deep work before late morning tomorrow.']),
    why: 'Based on your recent patterns, mornings have been your best window.',
    kind: 'predictive',
    confidence: 'Low'
  ));

  // Strength-based reinforcement if any reactive item exists
  if (tonight.isNotEmpty){
    final key = 'strength_highlight';
    if (!await AdvicePolicy.isOnCooldown(key)){
      nextDays.add(AdviceItem(
        key: key,
        text: Phrasing.oneOf(['You’ve been consistent with the habits that help.', 'Good consistency—keep the helpful bits in play.']),
        why: 'Balancing warnings with what’s working improves adherence.',
        kind: 'positive',
        confidence: 'High'
      ));
      await AdvicePolicy.markShown(key);
    }
  }

  return AdviceEngineResult(tonight: tonight, nextDays: nextDays);
}

String Phrasing.oneOf(List<String> options){
  options.shuffle();
  return options.first;
}
import 'novelty_service.dart';

import 'package:collection/collection.dart';
import '../services/db.dart';
import '../models/models.dart';
import 'rules_loader.dart';
import 'risk_monitor.dart';

class AdviceEngineResult{
  final String tonight;
  final String nextDays;
  final Map<String, dynamic> context;
  AdviceEngineResult({required this.tonight, required this.nextDays, required this.context});
}

class AdviceEngine{
  static Future<AdviceEngineResult> generate(DateTime day) async {
    final rules = await JournalRules.load();
    final risk = await RiskMonitor.evaluate(day);

    final entries = await AppDatabase.instance.all();
    if (entries.isEmpty){
      return AdviceEngineResult(
        tonight: 'Lights-out 23:00; screens off by 22:00. 4‑7‑8 (2 rounds) + 10 min breath meditation.',
        nextDays: 'Tomorrow: 30–40 min easy outdoor walk. Keep intensity sub‑threshold for 24–48h.',
        context: {'note':'no entries'}
      );
    }
    entries.sort((a,b)=> a.dateTime.compareTo(b.dateTime));
    JournalEntry today = entries.last;
    for (final e in entries){ if (_sameDay(e.dateTime, day)) { today = e; break; } }

    final start = DateTime(day.year, day.month, day.day).subtract(const Duration(days:6));
    final week = entries.where((e)=> !e.dateTime.isBefore(start)).toList();

    final ranToday = today.ranToday == true;
    final nightShift = today.nightShift == true;
    final words = today.words ?? 0;
    final stress = today.stress ?? 5;
    final mood = today.mood ?? 5;
    final text = (today.text ?? '').toLowerCase();

    final incidentWords = ['incident','restraint','aggressive','violent','emergency','code','seclusion','assault'];
    final hadIncident = incidentWords.any((w)=> text.contains(w));

    final avgWords = week.map((e)=> e.words??0).average;
    final sdWords = week.map((e)=> e.words??0).stdev;
    final activated = (stress >= 7) || (words > (avgWords + sdWords));

    final tempo = text.contains('tempo') || text.contains('interval');
    final longRun = text.contains('long run') || text.contains('longrun') || text.contains('18k') || text.contains('20k');
    final easyRun = text.contains('easy run') || text.contains('recovery run') || text.contains('easy');

    final tonightParts = <String>[];
    if (risk.rareBadDay){ tonightParts.add('Unusual day for you — keep the plan steady and simple.'); }
    final ctx = {'heavy_entry': heavyEntry, 'night_shift': nightShift, 'lex_act': lexAct, 'lex_calm': lexCalm, 'run_minutes': today.runMinutes??0};
    final fromRules = _fromRulesTonight(ctx, rules);
    if (fromRules.isNotEmpty){ tonightParts.addAll(fromRules); }
    if (nightShift && hadIncident){
      tonightParts.add('Wind‑down priority after a night shift with a significant incident.');
      tonightParts.add('Lights‑out around 23:00; screens off ≥60 min before.');
      tonightParts.add('4‑7‑8 (2–3 rounds, ~6–10 min) + 10–12 min breath or compassion practice.');
    } else if (nightShift){
      tonightParts.add('Post‑night‑shift recovery: keep wind‑down strict.');
      tonightParts.add('30–40 min easy walk or gentle mobility, then cool, dark room.');
      tonightParts.add('4‑7‑8 (2 rounds) before bed; eye mask recommended.');
    } else if (ranToday && (tempo || longRun)){
      tonightParts.add('You trained hard today; protect sleep.');
      tonightParts.add('Warm shower → 10 min legs‑up‑wall → 4‑7‑8 (1–2 rounds).');
      tonightParts.add('Avoid late screens; small carb+protein snack if needed.');
    } else if (activated || words > 600){
      tonightParts.add('High activation/processing day — aim to downshift.');
      tonightParts.add('4‑7‑8 (2–3 rounds, ~6–10 min) then 10–12 min breath‑focused practice.');
      tonightParts.add('Lights‑out target 23:00; park one worry for tomorrow.');
    } else {
      
      tonightParts.add('Screens off by 22:00; lights‑out near 23:00.');
      tonightParts.add('Optional: 4‑7‑8 (1–2 rounds) or short body scan.');
    }

    final nextParts = <String>[];
    if (risk.rareBadDay){ nextParts.add('Expect normalisation in ~24–48h; keep intensity low and routines consistent.'); }
    final ctx = {'heavy_entry': heavyEntry, 'night_shift': nightShift, 'lex_act': lexAct, 'lex_calm': lexCalm, 'run_minutes': today.runMinutes??0};
    final fromRulesN = _fromRulesNext(ctx, rules);
    if (fromRulesN.isNotEmpty){ nextParts.addAll(fromRulesN); }
    if (nightShift || hadIncident){
      nextParts.add('Tomorrow: easy 30–40 min outdoor walk/jog with morning light.');
      nextParts.add('Keep intensity sub‑threshold for 48h; prioritise sleep window.');
    } else if (ranToday && (tempo || longRun)){
      nextParts.add('Tomorrow: recovery‑biased day (easy movement only).');
      nextParts.add('Reintroduce tempo once sleep stabilises (≥2 good nights).');
    } else if (activated){
      nextParts.add('Next 2–3 days: minimum 10–12 min meditation daily; 4‑7‑8 each evening.');
      nextParts.add('Add 1 light social contact and a 20–30 min outdoor walk.');
    } else {
      nextParts.add('Maintain consistency: easy run/walk 30–45 min and your standard wind‑down.');
      nextParts.add('Keep bedtime within your usual window to consolidate gains.');
    }

    return AdviceEngineResult(
      tonight: '• ' + tonightParts.join('\n• '),
      nextDays: '• ' + nextParts.join('\n• '),
      context: {
        'night_shift': nightShift,
        'incident': hadIncident,
        'ran_today': ranToday,
        'tempo': tempo, 'long_run': longRun, 'easy_run': easyRun,
        'words': words, 'stress': stress, 'mood': mood
      }
    );
  }

  static bool _sameDay(DateTime a, DateTime b)=> a.year==b.year && a.month==b.month && a.day==b.day;
}

extension _NumList on Iterable<num>{
  double get average{
    final l = toList();
    if (l.isEmpty) return 0.0;
    return l.map((e)=> e.toDouble()).reduce((a,b)=> a+b) / l.length;
  }
  double get stdev{
    final l = toList().map((e)=> e.toDouble()).toList();
    if (l.length<2) return 0.0;
    final m = l.reduce((a,b)=> a+b)/l.length;
    final v = l.map((x)=> (x-m)*(x-m)).reduce((a,b)=> a+b) / (l.length-1);
    return v<=0?0.0: (v).sqrt();
  }
}
extension _Sqrt on double{ double sqrt()=> (this<=0)?0.0: (this**0.5); }

List<String> _fromRulesTonight(Map<String,dynamic> ctx, JournalRules rules){
  final out = <String>[];
  for (final r in rules.earlyWarnings){
    final cond = r['if'] as Map? ?? {};
    bool ok = true;
    for (final k in cond.keys){
      final v = cond[k];
      if (k == 'heavy_entry'){ if ((ctx['heavy_entry']??false) != true) ok = false; }
      else if (k == 'night_shift_day'){ if ((ctx['night_shift']??false) != true) ok = false; }
      else if (k == 'lex_act_at_least'){ if ((ctx['lex_act']??0) < (v as num).toInt()) ok = false; }
      else if (k == 'run_minutes_ge'){ if ((ctx['run_minutes']??0) < (v as num).toInt()) ok = false; }
      else if (k == 'lex_calm_at_least'){ if ((ctx['lex_calm']??0) < (v as num).toInt()) ok = false; }
    }
    if (ok){ for (final s in (r['then_tonight'] as List? ?? [])) out.add(s.toString()); }
  }
  return out;
}
List<String> _fromRulesNext(Map<String,dynamic> ctx, JournalRules rules){
  final out = <String>[];
  for (final r in rules.earlyWarnings){
    final cond = r['if'] as Map? ?? {};
    bool ok = true;
    for (final k in cond.keys){
      final v = cond[k];
      if (k == 'heavy_entry'){ if ((ctx['heavy_entry']??false) != true) ok = false; }
      else if (k == 'night_shift_day'){ if ((ctx['night_shift']??false) != true) ok = false; }
      else if (k == 'lex_act_at_least'){ if ((ctx['lex_act']??0) < (v as num).toInt()) ok = false; }
      else if (k == 'run_minutes_ge'){ if ((ctx['run_minutes']??0) < (v as num).toInt()) ok = false; }
      else if (k == 'lex_calm_at_least'){ if ((ctx['lex_calm']??0) < (v as num).toInt()) ok = false; }
    }
    if (ok){ for (final s in (r['then_next_days'] as List? ?? [])) out.add(s.toString()); }
  }
  return out;
}

// NOVELTY_HOOK: call NoveltyService.detect() with your latest texts vs previous window and attach to weekly digest or micro-trends.
