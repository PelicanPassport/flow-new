
import 'dart:math';
import '../models/models.dart';

class JournalSearch {
  static const _stop = {
    'the','a','an','and','or','for','to','of','in','on','at','is','it','this','that','with','as','be','are','was','were','by','from','about','into','over','after','before','up','down','out'
  };
  static const _syn = {
    'run': ['run','ran','jog','jogging','training','miles','km','pace'],
    'work': ['work','shift','night','day','ward','unit','nurse','team','manager'],
    'mood': ['mood','feeling','felt','emotion','happy','sad','anxious','calm','stressed','stress'],
    'sleep': ['sleep','asleep','wake','woke','bed','bedtime','rest','insomnia'],
    'recovery': ['recovery','rest','restore','fatigue','tired','energy'],
    'relapse': ['relapse','worry','urge','craving','compulsion','slip','setback'],
    'meditation': ['meditation','meditate','mindfulness','breathe','breathing','4-7-8']
  };

  static List<String> _tokenize(String s){
    return s.toLowerCase().replaceAll(RegExp(r'[^a-z0-9\s]'), ' ').split(RegExp(r'\s+')).where((t)=> t.isNotEmpty && !_stop.contains(t)).toList();
  }
  static List<String> _expand(List<String> base){
    final out = <String>[]..addAll(base);
    for(final t in base){ for(final e in _syn.entries){ if (e.value.contains(t)) out.addAll(e.value); } }
    return out.toSet().toList();
  }
  static int _editDistance(String a, String b){
    if (a==b) return 0; if ((a.length-b.length).abs()>1) return 2;
    if (a.length==b.length){
      int diff=0; int di=-1;
      for (int i=0;i<a.length;i++){ if (a[i]!=b[i]){ diff++; if (diff==1) di=i; if (diff>2) break; } }
      if (diff==1) return 1;
      if (diff==2 && di>=0 && di+1<a.length){ if (a[di]==b[di+1] && a[di+1]==b[di]) return 1; }
      return diff==0?0:2;
    } else {
      final s = a.length>b.length? a : b; final t = a.length>b.length? b : a;
      int i=0,j=0,ed=0;
      while (i<s.length && j<t.length){
        if (s[i]==t[j]){ i+=1;j+=1; } else { ed+=1; i+=1; if (ed>1) return 2; }
      }
      return ed + (s.length - i) <= 1 ? 1 : 2;
    }
  }
  static bool _fuzzyEq(String q, String t){ if (q==t) return true; if ((q.length<=4 || t.length<=4)) return false; return _editDistance(q,t) <= 1; }

  static List<_Doc> _prep(List<JournalEntry> corpus){
    return corpus.map((e){
      final text = (e.text ?? '').toLowerCase();
      final tokens = _tokenize(text);
      return _Doc(e, tokens, text);
    }).toList();
  }

  static (_Filters, String) _parse(String raw){
    final f = _Filters(); String q = raw;
    final reGe = RegExp(r'date:\s*>=\s*(\d{4}-\d{2}-\d{2})'); final m1 = reGe.firstMatch(q);
    if (m1!=null){ f.dateGe = DateTime.tryParse(m1.group(1)!); q = q.replaceFirst(m1.group(0)!, ''); }
    final reLe = RegExp(r'date:\s*<=\s*(\d{4}-\d{2}-\d{2})'); final m2 = reLe.firstMatch(q);
    if (m2!=null){ f.dateLe = DateTime.tryParse(m2.group(1)!); q = q.replaceFirst(m2.group(0)!, ''); }
    for (final key in ['mood','energy','stress','words']){
      final ge = RegExp('$key:\s*>=\s*(\d+)'); final me = ge.firstMatch(q);
      if (me!=null){ f.numGe[key] = double.parse(me.group(1)!); q=q.replaceFirst(me.group(0)!, ''); }
      final le = RegExp('$key:\s*<=\s*(\d+)'); final ml = le.firstMatch(q);
      if (ml!=null){ f.numLe[key] = double.parse(ml.group(1)!); q=q.replaceFirst(ml.group(0)!, ''); }
    }
    for (final key in ['work','night','ran']){
      final re = RegExp('$key:\s*(true|false)'); final m = re.firstMatch(q);
      if (m!=null){ f.boolEq[key] = (m.group(1)=='true'); q = q.replaceFirst(m.group(0)!, ''); }
    }
    return (f, q.trim());
  }
  static bool _pass(JournalEntry e, _Filters f){
    if (f.dateGe!=null && e.dateTime.isBefore(f.dateGe!)) return false;
    if (f.dateLe!=null && e.dateTime.isAfter(f.dateLe!.add(const Duration(days:1)))) return false;
    final nums = {'mood': e.mood.toDouble(), 'energy': e.energy.toDouble(), 'stress': e.stress.toDouble(), 'words': e.words.toDouble()};
    for (final k in f.numGe.keys){ if ((nums[k] ?? -1) < f.numGe[k]!) return false; }
    for (final k in f.numLe.keys){ if ((nums[k] ?? 1e9) > f.numLe[k]!) return false; }
    final bs = {'work': e.workDay, 'night': e.nightShift, 'ran': e.ranToday};
    for (final k in f.boolEq.keys){ if ((bs[k] ?? false) != f.boolEq[k]!) return false; }
    return true;
  }

  static List<JournalEntry> search(List<JournalEntry> corpus, String raw, {int topK=50}){
    final (filters, q) = _parse(raw);
    final docs = _prep(corpus).where((d)=> _pass(d.entry, filters)).toList();
    if (q.isEmpty){ docs.sort((a,b)=> b.entry.dateTime.compareTo(a.entry.dateTime)); return docs.take(topK).map((d)=> d.entry).toList(); }

    final phraseRe = RegExp(r'"([^"]+)"'); final phrases = phraseRe.allMatches(q).map((m)=> m.group(1)!.toLowerCase()).toList();
    final bare = q.replaceAll(phraseRe, ' ').trim();
    final qTokens = _expand(_tokenize(bare));

    const k1=1.5, b=0.75;
    final avgdl = docs.isEmpty? 1.0 : (docs.map((d)=> d.tokens.length).reduce((a,b)=> a+b) / docs.length);
    final df = <String,int>{}; for(final t in qTokens){ df[t] = docs.where((d)=> d.tokens.contains(t) || d.tokens.any((x)=> _fuzzyEq(t,x))).length; }
    double bm25(_Doc d){
      final dl = d.tokens.length.toDouble();
      double score=0.0;
      for(final t in qTokens){
        final freq = d.tokens.where((x)=> x==t || _fuzzyEq(t,x)).length.toDouble();
        if (freq==0) continue;
        final N = docs.length.toDouble();
        final idf = log( (N - (df[t]??0) + 0.5) / ((df[t]??0) + 0.5) + 1 );
        final denom = freq + k1*(1 - b + b*dl/avgdl);
        score += idf * (freq*(k1+1) / denom);
      }
      for(final ph in phrases){ if (d.text.contains(ph)) score += 1.0; }
      final ageDays = DateTime.now().difference(d.entry.dateTime).inDays.toDouble();
      final recency = 1.0 / (1.0 + ageDays/90.0);
      return score*0.9 + recency*0.3;
    }
    final scored = <(_Doc,double)>[]; for(final d in docs){ final s = bm25(d); if (s>0) scored.add((d,s)); }
    scored.sort((a,b)=> b.$2.compareTo(a.$2));
    return scored.take(topK).map((p)=> p.$1.entry).toList();
  }

  static String snippet(String text, String query, {int window=80}){
    final lower = text.toLowerCase();
    final phraseRe = RegExp(r'"([^"]+)"');
    for (final m in phraseRe.allMatches(query)){
      final ph = m.group(1)!.toLowerCase();
      final idx = lower.indexOf(ph);
      if (idx>=0){
        final start = (idx - window).clamp(0, lower.length);
        final end = (idx + ph.length + window).clamp(0, lower.length);
        return text.substring(start, end);
      }
    }
    final tokens = _expand(_tokenize(query));
    int bestIdx = -1; String? bestTok;
    for(final t in tokens){
      final idx = lower.indexOf(t);
      if (idx>=0 && (bestIdx==-1 || idx<bestIdx)){ bestIdx=idx; bestTok=t; }
    }
    if (bestIdx==-1) return text.length <= window*2 ? text : text.substring(0, min(text.length, window*2)) + '…';
    final start = max(0, bestIdx - window);
    final end = min(text.length, bestIdx + (bestTok?.length ?? 0) + window);
    return text.substring(start, end);
  }
}

class _Filters{
  DateTime? dateGe, dateLe;
  final Map<String,double> numGe = {};
  final Map<String,double> numLe = {};
  final Map<String,bool> boolEq = {};
}

class _Doc{
  final JournalEntry entry;
  final List<String> tokens;
  final String text;
  _Doc(this.entry, this.tokens, this.text);
}
