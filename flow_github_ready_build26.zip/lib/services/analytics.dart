
import 'dart:math';
import '../models/journal_entry.dart';

class Analytics {
  static Map<String, double> weeklyAverages(List<JournalEntry> entries) {
    if (entries.isEmpty) return {};
    // last 7 days
    final last = entries.where((e) => e.dateTime.isAfter(DateTime.now().subtract(const Duration(days: 7)))).toList();
    if (last.isEmpty) return {};
    double avg(List<int> xs) => xs.isEmpty ? 0 : xs.reduce((a,b)=>a+b)/xs.length;
    return {
      'mood': avg(last.map((e)=>e.mood).toList()),
      'energy': avg(last.map((e)=>e.energy).toList()),
      'focus': avg(last.map((e)=>e.focus).toList()),
      ')=>e.).toList()),
    };
    }

  static Map<String, double> trendSlopes30d(List<JournalEntry> entries) {
    double slope(List<MapEntry<double,double>> pts) {
      if (pts.length < 3) return 0.0;
      final n = pts.length.toDouble();
      final sx = pts.fold(0.0, (a,e)=>a+e.key);
      final sy = pts.fold(0.0, (a,e)=>a+e.value);
      final sxx = pts.fold(0.0, (a,e)=>a+e.key*e.key);
      final sxy = pts.fold(0.0, (a,e)=>a+e.key*e.value);
      final den = n*sxx - sx*sx;
      if (den == 0) return 0.0;
      return (n*sxy - sx*sy)/den;
    }
    List<MapEntry<double,double>> series(int Function(JournalEntry) get) =>
      entries.map((e)=>MapEntry(e.dateTime.millisecondsSinceEpoch/86400000.0, get(e).toDouble())).toList();
    return {
      'mood': slope(series((e)=>e.mood))*30.0,
      'energy': slope(series((e)=>e.energy))*30.0,
      'focus': slope(series((e)=>e.focus))*30.0,
      ')=>e.))*30.0,
    };
  }

  static List<String> anomalies(List<JournalEntry> entries) {
    if (entries.isEmpty) return [];
    final w = entries.reversed.take(14).toList().reversed.toList();
    double? zscore(List<int> xs, int v) {
      if (xs.length < 5) return null;
      final mean = xs.reduce((a,b)=>a+b)/xs.length;
      final varr = xs.map((x)=>pow(x-mean,2)).reduce((a,b)=>a+b)/xs.length;
      final sd = sqrt(varr);
      if (sd == 0) return null;
      return (v-mean)/sd;
    }
    final last = entries.last;
    final res = <String>[];
    final zMood = zscore(w.map((e)=>e.mood).toList(), last.mood);
    if (zMood != null && zMood.abs() > 2) res.add('Mood unusually ${zMood>0?'high':'low'} today.');
    final zEn = zscore(w.map((e)=>e.energy).toList(), last.energy);
    if (zEn != null && zEn.abs() > 2) res.add('Energy unusually ${zEn>0?'high':'low'} today.');
    final zAnx = zscore(w.map((e)=>e.focus).toList(), last.focus);
    if (zAnx != null && zAnx.abs() > 2) res.add('Focus unusually ${zAnx>0?'high':'low'} today.');
    return res;
  }
}
