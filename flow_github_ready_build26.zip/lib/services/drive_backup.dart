
import 'dart:io';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:extension_google_sign_in_as_googleapis_auth/extension_google_sign_in_as_googleapis_auth.dart';
import 'package:googleapis/drive/v3.dart' as drive;
import 'package:path_provider/path_provider.dart';

class DriveBackup {
  static final _signIn = GoogleSignIn(scopes: <String>[drive.DriveApi.driveFileScope]);
  static drive.DriveApi? _api;

  static Future<bool> ensureSignedIn() async {
    var acct = await _signIn.signInSilently();
    acct ??= await _signIn.signIn();
    if (acct == null) return false;
    final auth = await _signIn.authenticatedClient();
    if (auth == null) return false;
    _api = drive.DriveApi(auth);
    return true;
  }

  static Future<String> _ensureAppFolder() async {
    final api = _api!;
    final q = "mimeType='application/vnd.google-apps.folder' and name='SupremeJournal Backups' and trashed=false";
    final res = await api.files.list(q: q, $fields: 'files(id,name)');
    if (res.files != null && res.files!.isNotEmpty) return res.files!.first.id!;
    final folder = drive.File()
      ..name = 'SupremeJournal Backups'
      ..mimeType = 'application/vnd.google-apps.folder';
    final created = await api.files.create(folder);
    return created.id!;
  }

  static Future<String> backupNow() async {
    if (_api == null) {
      final ok = await ensureSignedIn();
      if (!ok) return 'Sign-in failed';
    }
    final api = _api!;
    final dir = await getApplicationDocumentsDirectory();
    final paths = <String>[];

    final jsonl = File('${dir.path}/supreme_export.jsonl');
    if (await jsonl.exists()) paths.add(jsonl.path);

    final cog = File('${dir.path}/cog_games.jsonl');
    if (await cog.exists()) paths.add(cog.path);

    if (paths.isEmpty) return 'No export files found. Use Export first.';

    final folderId = await _ensureAppFolder();
    String lastId = '';

    for (final p in paths){
      final fn = p.split('/').last;
      final media = drive.Media(File(p).openRead(), await File(p).length());
      final meta = drive.File()
        ..name = fn
        ..parents = [folderId];
      final up = await api.files.create(meta, uploadMedia: media);
      lastId = up.id ?? '';
    }
    return lastId.isEmpty ? 'Uploaded' : 'Uploaded (last id: $lastId)';
  }
}


  /// Return list of files under Drive/SupremeJournal (name, id, modified time).
  static Future<List<Map<String,String>>> listBackups() async {
    final api = await _api();
    final q = "name contains 'supreme_export' or name contains 'cog_games'";
    final res = await api.files.list(q: q, $fields: 'files(id,name,modifiedTime)', orderBy: 'modifiedTime desc');
    final out = <Map<String,String>>[];
    for (final f in res.files ?? []){
      out.add({'id': f.id ?? '', 'name': f.name ?? '', 'modified': f.modifiedTime?.toIso8601String() ?? ''});
    }
    return out;
  }

  /// Download a file by id to app documents directory; returns local path.
  static Future<String> downloadById(String id, {String? filename}) async {
    final api = await _api();
    final media = await api.files.get(id, downloadOptions: drive.DownloadOptions.fullMedia) as drive.Media;
    final dir = await getApplicationDocumentsDirectory();
    final path = '${dir.path}/${filename ?? ('restore_' + id)}';
    final sink = File(path).openWrite();
    await media.stream.pipe(sink);
    await sink.close();
    return path;
  }

  /// Smart auto-backup: if last backup >24h ago and user previously signed in, try backup.
  static Future<String?> maybeSmartAutoBackup(Future<String?> Function(String key) getSetting, Future<void> Function(String key, String val) setSetting) async {
    try{
      final last = await getSetting('last_backup_iso');
      final now = DateTime.now();
      if (last!=null && last.isNotEmpty){
        final t = DateTime.tryParse(last);
        if (t!=null && now.difference(t).inHours < 24) return null;
      }
      final msg = await backupAll();
      await setSetting('last_backup_iso', now.toIso8601String());
      return msg;
    } catch(_){
      return null;
    }
  }
