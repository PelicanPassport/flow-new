
import '../models/journal_entry.dart';

class PromptEngine {
  static List<String> baseCreatives = [
    'What surprised you today?',
    'Describe the best 5 minutes of your day.',
    'If today was a movie scene, what happened?',
    'What are you grateful for right now?',
    'What did you learn or notice today?',
  ];
  static List<String> reflections = [
    'What challenge did you handle well?',
    'What would you tell your future self about this week?',
    'Where did you show courage?',
    'What would make tomorrow 5% better?',
  ];
  static List<String> variety = [
    'Write one sentence that captures today’s mood.',
    'Name one small thing that mattered.',
    'Who did you connect with today and how?',
    'What decision are you glad you made recently?',
  ];

  static String pickPrompt(List<JournalEntry> recent) {
    // Simple coverage: if no long entries lately, push reflective;
    // else rotate among pools.
    final hasDepth = recent.any((e) => e.text.split(RegExp(r'\s+')).length >= 80);
    if (!hasDepth) return reflections[(DateTime.now().day) % reflections.length];
    final pools = [baseCreatives, reflections, variety];
    final p = pools[DateTime.now().day % pools.length];
    return p[(DateTime.now().weekday) % p.length];
  }
}
