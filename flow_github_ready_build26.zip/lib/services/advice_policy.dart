
import 'package:shared_preferences/shared_preferences.dart';

enum AdviceLevel { high, balanced, low }

class AdvicePolicy {
  static const _kLevel = 'advice_level';
  static const _kLastShownPrefix = 'advice_last_'; // + key

  static Future<AdviceLevel> level() async {
    final sp = await SharedPreferences.getInstance();
    final v = sp.getString(_kLevel) ?? 'balanced';
    switch (v) {
      case 'high': return AdviceLevel.high;
      case 'low': return AdviceLevel.low;
      default: return AdviceLevel.balanced;
    }
  }

  static Future<void> setLevel(AdviceLevel lv) async {
    final sp = await SharedPreferences.getInstance();
    final v = lv==AdviceLevel.high ? 'high' : lv==AdviceLevel.low ? 'low' : 'balanced';
    await sp.setString(_kLevel, v);
  }

  // Cooldown in days per level (how often we can repeat the same advice key)
  static int cooldownDays(AdviceLevel lv){
    switch (lv){
      case AdviceLevel.high: return 3;
      case AdviceLevel.balanced: return 10;
      case AdviceLevel.low: return 21;
    }
  }

  static Future<bool> isOnCooldown(String key) async {
    final sp = await SharedPreferences.getInstance();
    final last = sp.getInt(_kLastShownPrefix+key) ?? 0;
    if (last==0) return false;
    final days = DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(last)).inDays;
    final lv = await level();
    return days < cooldownDays(lv);
  }

  static Future<void> markShown(String key) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setInt(_kLastShownPrefix+key, DateTime.now().millisecondsSinceEpoch);
  }
}
