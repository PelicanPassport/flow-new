
import 'package:shared_preferences/shared_preferences.dart';

class MicroExperiment {
  final String id;
  final String title;
  final String tonightAction;
  final String trackMetric; // e.g., 'calm_tone', 'energy', 'focus'
  final int durationDays;   // 5-7 days typical
  MicroExperiment({required this.id, required this.title, required this.tonightAction, required this.trackMetric, required this.durationDays});
}

class ExperimentsService {
  static const _kLastStart = 'exp_last_start_epoch';
  static const _kActiveId = 'exp_active_id';

  static Future<MicroExperiment?> getActive() async {
    final sp = await SharedPreferences.getInstance();
    final id = sp.getString(_kActiveId);
    if (id == null) return null;
    return _catalog().firstWhere((e)=> e.id==id, orElse: ()=> _catalog().first);
  }

  static Future<bool> shouldStartNew() async {
    final sp = await SharedPreferences.getInstance();
    final last = sp.getInt(_kLastStart) ?? 0;
    final now = DateTime.now().millisecondsSinceEpoch;
    // Start around once per quarter (90 days)
    return (now - last) > 90*24*60*60*1000;
  }

  static Future<MicroExperiment> startNew() async {
    final sp = await SharedPreferences.getInstance();
    final choice = _catalog()[DateTime.now().millisecondsSinceEpoch % _catalog().length];
    await sp.setString(_kActiveId, choice.id);
    await sp.setInt(_kLastStart, DateTime.now().millisecondsSinceEpoch);
    return choice;
  }

  static Future<void> clear() async {
    final sp = await SharedPreferences.getInstance();
    await sp.remove(_kActiveId);
  }

  static List<MicroExperiment> _catalog(){
    return [
      MicroExperiment(
        id:'journal_early',
        title:'Journal earlier for a week',
        tonightAction:'Try journaling before 19:30.',
        trackMetric:'clarity'
      , durationDays:7),
      MicroExperiment(
        id:'walk_evening',
        title:'Add a 15–20m evening walk',
        tonightAction:'Walk 15–20 minutes after dinner.',
        trackMetric:'calm_tone'
      , durationDays:6),
      MicroExperiment(
        id:'run_35min',
        title:'Run 30–40 minutes, 3x this week',
        tonightAction:'Plan a 35m easy run tomorrow.',
        trackMetric:'mood_stability'
      , durationDays:7),
      MicroExperiment(
        id:'caffeine_cap',
        title:'No caffeine after 14:00',
        tonightAction:'Cap caffeine at 14:00 tomorrow.',
        trackMetric:'sleep_quality'
      , durationDays:5),
      MicroExperiment(
        id:'gratitude_2',
        title:'Two-line gratitude at end of entry',
        tonightAction:'Add two lines of gratitude.',
        trackMetric:'positive_tone'
      , durationDays:7),
    ];
  }
}
