
class HabitImpact {
  final String habit;
  final double recentImpact; // latest 14 days effect size
  final double priorImpact;  // previous 14 days effect size
  final bool plateau;        // if recent <= prior * 0.7 (30% drop)
  HabitImpact(this.habit, this.recentImpact, this.priorImpact, this.plateau);
}

// This is a placeholder; the real implementation would compute impact from your stored metrics.
class HabitPlateau {
  static List<HabitImpact> detect(Map<String, List<double>> habitEffectSeries){
    final out = <HabitImpact>[];
    habitEffectSeries.forEach((habit, series){
      if (series.length < 28) return;
      final recent = series.sublist(series.length-14).reduce((a,b)=>a+b)/14.0;
      final prior  = series.sublist(series.length-28, series.length-14).reduce((a,b)=>a+b)/14.0;
      final plat = recent <= prior * 0.7;
      out.add(HabitImpact(habit, recent, prior, plat));
    });
    return out;
  }
}
