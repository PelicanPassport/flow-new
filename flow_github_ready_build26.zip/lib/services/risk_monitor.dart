
import '../services/db.dart';
import '../models/models.dart';
import 'package:collection/collection.dart';

class RiskSnapshot{
  final bool rareBadDay;
  final List<String> reasons;
  const RiskSnapshot({required this.rareBadDay, required this.reasons});
}

class RiskMonitor{
  /// Flags a "rare bad day" using simple z-like checks vs YTD baselines from entries only.
  static Future<RiskSnapshot> evaluate(DateTime day) async {
    final entries = await AppDatabase.instance.all();
    if (entries.length < 30) return const RiskSnapshot(rareBadDay:false, reasons:[]);
    final now = DateTime(day.year, day.month, day.day);
    final yStart = DateTime(now.year, 1, 1);
    final ytd = entries.where((e)=> !e.dateTime.isBefore(yStart)).toList();
    final today = entries.where((e)=> e.dateTime.year==now.year && e.dateTime.month==now.month && e.dateTime.day==now.day).lastOrNull ?? entries.last;

    // Helpers
    double avg(Iterable<num> xs)=> xs.isEmpty?0: xs.map((e)=> e.toDouble()).average;
    double sd(Iterable<num> xs){
      final l = xs.map((e)=> e.toDouble()).toList();
      if (l.length<2) return 0;
      final m = avg(l);
      final v = l.map((x)=> (x-m)*(x-m)).reduce((a,b)=> a+b) / (l.length-1);
      return v<=0?0: (v).sqrt();
    }
    double z(num x, Iterable<num> base){
      final m = avg(base);
      final s = sd(base);
      if (s==0) return 0;
      return (x.toDouble()-m)/s;
    }

    final moods = ytd.map((e)=> e.mood??5);
    final stresses = ytd.map((e)=> e.stress??5);
    final words = ytd.map((e)=> e.words??0);

    final zMood = z(today.mood??5, moods);
    final zStress = z(today.stress??5, stresses);
    final zWords = z(today.words??0, words);

    final reasons = <String>[];
    bool flag = false;

    if (zMood < -1.2) { flag = true; reasons.add('Mood is well below your YTD typical range.'); }
    if (zStress >  1.2) { flag = true; reasons.add('Stress is well above your YTD typical range.'); }
    if (zWords >  1.2) { reasons.add('Heavy entry (lots of processing) compared to usual.'); }

    // Context cues from text
    final t = (today.text??'').toLowerCase();
    final incidentWords = ['incident','restraint','aggressive','violent','emergency','code','seclusion','assault'];
    if (incidentWords.any((w)=> t.contains(w))) reasons.add('Significant incident noted today.');

    return RiskSnapshot(rareBadDay: flag, reasons: reasons);
  }
}

extension on Iterable<num>{
  double get average{
    final l = toList();
    if (l.isEmpty) return 0.0;
    return l.map((e)=> e.toDouble()).reduce((a,b)=> a+b) / l.length;
  }
}
extension _Sqrt on double{ double sqrt()=> (this<=0)?0.0: (this**0.5); }
