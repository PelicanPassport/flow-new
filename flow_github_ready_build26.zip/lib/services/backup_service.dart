
import 'package:shared_preferences/shared_preferences.dart';

class BackupService {
  static const _kLast = 'last_backup_epoch';
  static Future<bool> shouldBackupNow() async {
    final sp = await SharedPreferences.getInstance();
    final last = sp.getInt(_kLast) ?? 0;
    final now = DateTime.now().millisecondsSinceEpoch;
    // 7 days in ms
    if (now - last > 7*24*60*60*1000) return true;
    return false;
  }
  static Future<void> markBackedUp() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setInt(_kLast, DateTime.now().millisecondsSinceEpoch);
  }
}
