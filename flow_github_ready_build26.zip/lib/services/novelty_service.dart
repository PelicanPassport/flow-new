
import 'dart:math';
import 'package:collection/collection.dart';

class NoveltyInsight {
  final String phrase;
  final double lift; // how much more common vs baseline
  final String confidence; // Low / Medium / High
  NoveltyInsight(this.phrase, this.lift, this.confidence);
}

class NoveltyService {
  // Naive tokenizer; in real use we may want stemming.
  static List<String> _tokens(String text){
    final t = text.toLowerCase().replaceAll(RegExp(r'[^a-z0-9\s]'),' ');
    final words = t.split(RegExp(r'\s+')).where((w)=> w.length>=4).toList();
    return words;
  }

  // Returns up to N phrases that increased in the recent window vs previous.
  static List<NoveltyInsight> detect({
    required List<String> last30Texts,
    required List<String> prev30Texts,
    int topN = 3,
  }){
    Map<String,int> cLast = {}, cPrev = {};
    for (final t in last30Texts){ for(final w in _tokens(t)){ cLast[w] = (cLast[w]??0)+1; } }
    for (final t in prev30Texts){ for(final w in _tokens(t)){ cPrev[w] = (cPrev[w]??0)+1; } }
    final candidates = <NoveltyInsight>[];
    for (final e in cLast.entries){
      final w = e.key; final a = e.value.toDouble(); final b = (cPrev[w]??0).toDouble();
      if (a >= 3 && a > b){ // at least 3 mentions and an increase
        final lift = (a+1.0)/(b+1.0);
        String conf = 'Low';
        if (a>=5 && lift>=1.5) conf = 'Medium';
        if (a>=7 && lift>=2.0) conf = 'High';
        candidates.add(NoveltyInsight(w, lift, conf));
      }
    }
    candidates.sort((x,y)=> y.lift.compareTo(x.lift));
    return candidates.take(topN).toList();
  }
}
