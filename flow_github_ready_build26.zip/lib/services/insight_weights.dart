
import 'package:shared_preferences/shared_preferences.dart';

class InsightWeights {
  static const _kPrefix = 'insight_weight_';
  // delta can be +1 or -1
  static Future<void> vote(String key, int delta) async {
    final sp = await SharedPreferences.getInstance();
    final cur = sp.getInt(_kPrefix+key) ?? 0;
    await sp.setInt(_kPrefix+key, cur + delta);
  }
  static Future<int> get(String key) async {
    final sp = await SharedPreferences.getInstance();
    return sp.getInt(_kPrefix+key) ?? 0;
  }
}
