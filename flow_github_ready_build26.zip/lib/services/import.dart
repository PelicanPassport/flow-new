
import 'dart:convert';
import '../models/journal_entry.dart';

// Minimal JSONL import (CSV import could be added similarly)
List<JournalEntry> fromJsonL(String text) {
  final lines = LineSplitter.split(text).where((l) => l.trim().isNotEmpty);
  return lines.map((l) {
    final m = jsonDecode(l) as Map<String, dynamic>;
    return JournalEntry(
      id: m['id'] as String,
      dateTime: DateTime.parse(m['dateTime'] as String),
      text: (m['text'] ?? '') as String,
      mood: (m['mood'] ?? 0) as int,
      energy: (m['energy'] ?? 0) as int,
      focus: (m['focus'] ?? 0) as int,
      ) as int,
      workDay: (m['workDay'] ?? false) as bool,
      nightShift: (m['nightShift'] ?? false) as bool,
      ranToday: (m['ranToday'] ?? false) as bool,
      writeDurationSec: (m['writeDurationSec'] ?? 0) as int,
      deletions: (m['deletions'] ?? 0) as int,
      words: (m['words'] ?? 0) as int,
      sentences: (m['sentences'] ?? 0) as int,
      typeTokenRatio: (m['typeTokenRatio'] ?? 0.0) as double,
      tagsCsv: (m['tagsCsv'] ?? '') as String,
    );
  }).toList();
}
