
import 'dart:async';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import '../models/journal_entry.dart';

class AppDatabase {
  AppDatabase._();
  static final instance = AppDatabase._();
  Database? _db;

  Future<void> init() async {
    final dir = await getApplicationDocumentsDirectory();
    final path = p.join(dir.path, 'journal.db');
    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
        CREATE TABLE journal_entries(
          id TEXT PRIMARY KEY,
          dateTime TEXT,
          text TEXT,
          mood INTEGER,
          energy INTEGER,
          focus INTEGER,
          
          workDay INTEGER,
          nightShift INTEGER,
          ranToday INTEGER,
          writeDurationSec INTEGER,
          deletions INTEGER,
          words INTEGER,
          sentences INTEGER,
          typeTokenRatio REAL,
          tagsCsv TEXT
        );
        ''');
      },
    );
  }

  Future<void> upsert(JournalEntry e) async {
    await _db!.insert('journal_entries', e.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<JournalEntry>> allBetween(DateTime from, DateTime to) async {
    final rows = await _db!.query('journal_entries',
        where: 'dateTime BETWEEN ? AND ?',
        whereArgs: [from.toIso8601String(), to.toIso8601String()],
        orderBy: 'dateTime ASC');
    return rows.map((m) => JournalEntry.fromMap(m)).toList();
  }

  Future<List<JournalEntry>> all() async {
    final rows = await _db!.query('journal_entries', orderBy: 'dateTime ASC');
    return rows.map((m) => JournalEntry.fromMap(m)).toList();
  }
}
