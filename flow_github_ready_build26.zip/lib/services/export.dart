
import 'dart:convert';
import '../models/journal_entry.dart';

String toCsv(List<JournalEntry> list) {
  final headers = [
    'date','time','timezone','journal_text','tags',
    'mood_valence','energy','anxiety','focus','
    'work_day','night_shift','ran_today',
    'write_duration_sec','chars_deleted','word_count','sentence_count','type_token_ratio',
    'entry_id'
  ];
  final b = StringBuffer()..writeln(headers.join(','));
  for (final e in list) {
    final dt = e.dateTime;
    final row = [
      dt.toIso8601String().split('T').first,
      dt.toIso8601String().split('T').last.substring(0,5),
      'Europe/London',
      _escape(e.text.replaceAll('\n',' ')),
      _escape(e.tagsCsv),
      e.mood.toString(),
      e.energy.toString(),
      '', // anxiety intentionally blank (not tracked)
      e.focus.toString(),
      e.),
      e.workDay.toString(),
      e.nightShift.toString(),
      e.ranToday.toString(),
      e.writeDurationSec.toString(),
      e.deletions.toString(),
      e.words.toString(),
      e.sentences.toString(),
      e.typeTokenRatio.toStringAsFixed(3),
      e.id,
    ];
    b.writeln(row.join(','));
  }
  return b.toString();
}

String toJsonL(List<JournalEntry> list) {
  return list.map((e) => jsonEncode({
    'id': e.id,
    'dateTime': e.dateTime.toIso8601String(),
    'text': e.text,
    'mood': e.mood,
    'energy': e.energy,
    'focus': e.focus,
    '
    'workDay': e.workDay,
    'nightShift': e.nightShift,
    'ranToday': e.ranToday,
    'writeDurationSec': e.writeDurationSec,
    'deletions': e.deletions,
    'words': e.words,
    'sentences': e.sentences,
    'typeTokenRatio': e.typeTokenRatio,
    'tagsCsv': e.tagsCsv,
  })).join('\n');
}

String _escape(String s) {
  final t = s.replaceAll('"','""').replaceAll(',', ' ');
  return '"$t"';
}
