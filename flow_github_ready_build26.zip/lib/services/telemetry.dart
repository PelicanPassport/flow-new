
import 'dart:io';
import 'dart:convert';
import 'package:path_provider/path_provider.dart';

class Telemetry {
  static Future<void> logGame(String game, int score, DateTime when) async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/cog_games.jsonl');
    final row = jsonEncode({'ts': when.toIso8601String(), 'game': game, 'score': score});
    await file.writeAsString(row + '\n', mode: FileMode.append, flush: true);
  }
}
