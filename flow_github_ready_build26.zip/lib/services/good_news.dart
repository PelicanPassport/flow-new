
import '../services/db.dart';
import '../models/models.dart';
import 'package:collection/collection.dart';

class GoodNews {
  static final Set<String> _posWords = {
    'calm','grateful','proud','content','hope','progress','better','steady','clear','energised','rested','connected','joy','ease','peace'
  };
  static final Set<String> _negRum = {
    'should','must','always','never','stuck','can\'t','loop','ruminate','overthink','spiral','why','what if'
  };
  static double _sentiment(String? text){
    if (text==null || text.isEmpty) return 0.0;
    final t = text.toLowerCase();
    int pos = 0, neg = 0;
    for (final w in _posWords){ if (t.contains(w)) pos++; }
    for (final w in _negRum){ if (t.contains(w)) neg++; }
    return pos - neg*0.8;
  }
  static int _streakMoodAbove(List<JournalEntry> entries, double ytdMood){
    int streak = 0;
    final sorted = [...entries]..sort((a,b)=> b.dateTime.compareTo(a.dateTime));
    for (final e in sorted){
      final m = e.mood ?? ytdMood;
      if (m >= ytdMood) { streak++; } else { break; }
    }
    return streak;
  }
  static int _streakLowStress(List<JournalEntry> entries, double ytdStress){
    int streak = 0;
    final sorted = [...entries]..sort((a,b)=> b.dateTime.compareTo(a.dateTime));
    for (final e in sorted){
      final s = e.stress ?? ytdStress;
      if (s <= ytdStress) { streak++; } else { break; }
    }
    return streak;
  }
  static int _streakActivity(List<JournalEntry> entries){
    int streak = 0;
    final sorted = [...entries]..sort((a,b)=> b.dateTime.compareTo(a.dateTime));
    for (final e in sorted){
      if (e.ranToday == true) { streak++; } else { break; }
    }
    return streak;
  }

  /// Computes a simple weekly vs YTD "doing well" score and bullet reasons.
  static Future<({double score, List<String> reasons, Map<String,int> streaks, double sentimentDelta})> evaluate(DateTime day) async {
    final entries = await AppDatabase.instance.all();
    if (entries.isEmpty) return (score: 0.0, reasons: [], streaks: {}, sentimentDelta: 0.0);
    final now = DateTime(day.year, day.month, day.day);
    final weekStart = now.subtract(Duration(days: now.weekday-1));
    final ytdStart = DateTime(now.year, 1, 1);

    final thisWeek = entries.where((e)=> !e.dateTime.isBefore(weekStart)).toList();
    final ytd = entries.where((e)=> !e.dateTime.isBefore(ytdStart)).toList();

    double avgMood(List<JournalEntry> xs)=> xs.map((e)=> e.mood).whereNotNull().average;
    double avgStress(List<JournalEntry> xs)=> xs.map((e)=> e.stress).whereNotNull().average;
    int runs(List<JournalEntry> xs)=> xs.where((e)=> e.ranToday==true).length;
    int nights(List<JournalEntry> xs)=> xs.where((e)=> e.nightShift==true).length;
    int words(List<JournalEntry> xs)=> xs.map((e)=> e.words??0).sum;

    final mW = avgMood(thisWeek); final mY = avgMood(ytd);
    final sW = avgStress(thisWeek); final sY = avgStress(ytd);
    final rW = runs(thisWeek); final rY = (ytd.isEmpty?0: (runs(ytd) / ((ytd.length/7).clamp(1, 52))).round());
    final wW = words(thisWeek); final wY = (ytd.isEmpty?0: (words(ytd) / ((ytd.length/7).ceil())));

    double pct(double a,double b){ if (b==0) return 0; return ((a-b)/b)*100.0; }
    final moodUp = pct(mW, mY);
    final stressDown = pct(sY, sW); // inverted
    final runsConsistent = pct(rW.toDouble(), rY.toDouble());
    final expressive = pct(wW.toDouble(), wY.toDouble());

    // Score: weighted positives; cap each contribution
    double score = 0;
    score += moodUp.clamp(-10, 20) * 0.04;       // up to +0.8
    score += stressDown.clamp(-10, 20) * 0.04;   // up to +0.8
    score += runsConsistent.clamp(-25, 25) * 0.02; // up to +0.5
    score += expressive.clamp(-25, 25) * 0.01;     // up to +0.25

    // Positive reasons
    final reasons = <String>[];
    if (moodUp > 4) reasons.add('Mood is up vs your YTD baseline.');
    if (stressDown > 4) reasons.add('Stress is lower than your YTD average.');
    if (runsConsistent >= 0) reasons.add('Activity is at or above your typical weekly level.');
    if (expressive >= 0) reasons.add('You're writing consistently (good processing signal).');

    return (score: score, reasons: reasons);
  }
}

extension _Avg on Iterable<num>{
  double get average{
    final l = toList();
    if (l.isEmpty) return 0.0;
    return l.map((e)=> e.toDouble()).reduce((a,b)=> a+b) / l.length;
  }
}
