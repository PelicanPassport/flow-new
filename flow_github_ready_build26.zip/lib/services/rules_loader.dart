
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;

class JournalRules {
  final Map<String, dynamic> data;
  JournalRules(this.data);
  static Future<JournalRules> load() async {
    final txt = await rootBundle.loadString('assets/journal_only_rules_v1.json');
    return JournalRules(json.decode(txt) as Map<String, dynamic>);
  }
  String get version => (data['version'] ?? '').toString();
  Map<String, dynamic> get thresholds => (data['thresholds'] as Map).map((k,v)=> MapEntry(k.toString(), v));
  List get earlyWarnings => (data['early_warnings'] as List? ?? []);
  List get positives => (data['positive_momentum'] as List? ?? []);
  Map<String, dynamic> get notes => (data['notes'] as Map? ?? {});
}
