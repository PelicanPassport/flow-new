
import 'package:flutter/material.dart';
import 'screens/settings.dart';
import 'services/backup_service.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:local_auth/local_auth.dart';
import 'package:intl/intl.dart';

import 'screens/home_screen.dart';
import 'services/db.dart';

void main()) async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppDatabase.instance.init();
  WidgetsFlutterBinding.ensureInitialized();
  await Notify.init();
  // Smart auto-backup if last one >24h
  await DriveBackup.maybeSmartAutoBackup(AppDatabase.instance.getSetting, AppDatabase.instance.setSetting);
  runApp(const SupremeJournalApp());
}

class SupremeJournalApp extends StatelessWidget {
  const SupremeJournalApp({super.key});

  @override
  Widget build(BuildContext context) {
    final base = ThemeData(
      useMaterial3: true, colorSchemeSeed: _seed,
      colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
      textTheme: GoogleFonts.robotoTextTheme(),
    );
    return AnimatedTheme(duration: const Duration(milliseconds: 280), curve: Curves.easeOutCubic, data: Theme.of(context), child: MaterialApp(
      title: "Flow",
      theme: base,
      darkTheme: ThemeData(
        useMaterial3: true, colorSchemeSeed: _seed,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal, brightness: Brightness.dark),
        textTheme: GoogleFonts.robotoTextTheme(ThemeData.dark().textTheme),
      ),
      routes:{'/settings':(_)=> SettingsScreen(onApplyTheme: _applyTheme)},
      home: const BiometricGate(child: HomeScreen()),
    );
  }
}

class BiometricGate extends StatefulWidget {
  final Widget child;
  const BiometricGate({super.key, required this.child});
  @override
  State<BiometricGate> createState() => _BiometricGateState();
}

class _BiometricGateState extends State<BiometricGate> {
  final LocalAuthentication auth = LocalAuthentication();
  bool unlocked = false;

  @override
  void initState() {
    super.initState();
    _unlock();
  }

  Future<void> _unlock() async {
    try {
      final can = await auth.canCheckBiometrics || await auth.isDeviceSupported();
      if (!can) { setState(() => unlocked = true); return; }
      final ok = await auth.authenticate(
        localizedReason: 'Unlock your journal',
        options: const AuthenticationOptions(stickyAuth: true, biometricOnly: false),
      );
      setState(() => unlocked = ok);
    } catch (_) {
      setState(() => unlocked = true);
    }
  }

  @override
  Widget build(BuildContext context) => unlocked ? widget.child : const Scaffold(
    body: Center(child: CircularProgressIndicator()),
  );
}
