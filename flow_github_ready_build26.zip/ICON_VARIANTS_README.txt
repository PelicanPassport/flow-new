
Dynamic icon variants are set via activity-alias:
- FlowGreen -> @mipmap/ic_launcher (default)
- FlowBlue  -> @mipmap/ic_launcher_alt

You can add more aliases/icons per theme if desired. Current code switches between Green and Blue.
