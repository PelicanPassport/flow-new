
# Flow – Build 22
- Learning weeks: quarterly micro-experiments with tonight action prompts.
- Habit plateau detector: flags habits whose impact has dropped ~30% vs previous month.
- Weekly digest: can show experiment banner and plateau tiles alongside top 3 insights.
- Novelty/confidence from Build 21 maintained; you can vote insights to reweight.
- Performance: Reports screen loads deferred to speed up startup.
